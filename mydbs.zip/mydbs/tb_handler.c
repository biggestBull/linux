#include"./db_manager.h"
#define TB_RECORD_LINE_SIZE 100
#define TB_PRE_MIN_SIZE 8192
#define TB_PRE_MAX_SIZE 1000000
#define ITEM_MAX 10

extern int init_tb_list(struct TB_MANAGER_ST * volatile * );
extern int init_thr_list(thr_manager_st **);

extern int thr_max;
extern int int_timer; 
extern int tb_max_num;
extern struct msghdr ipc_msg;

static int tb_record_fd;
static int tb_record_swap_fd;
static int tb_record_swap_flag;

static volatile int tb_cur_num;
static volatile int thr_cur_num;
static char buf[TB_RECORD_LINE_SIZE];
static char path_buf[70]; 
static char path_swap_buf[70]; 
struct TB_MANAGER_ST * volatile t_ms;
db_lock_st dls;

static int
tb_to_file(int fd,int line_size,void * tb_line_p){
    if(write(fd,tb_line_p,line_size)!=line_size)
        return -1;
    return 0;
}

static int
update_tb_item(int fd,tb_item_st * tb_item){
   static int flag=0;
   static char *tb_item_record;
   int exec_result=0;

   if(flag==0){
       if((tb_item_record=malloc(sizeof(tb_name_t)+12))==NULL)
           errExit("malloc for tb_item_record failed!\n");
       flag=1;
   }
   while(tb_item!=NULL){
      snprintf(tb_item_record,sizeof(tb_name_t)+12,"%s:%d:%d\n",tb_item->tb_item_nm,tb_item->var_type,tb_item->relate_offset);
      if(write(fd,tb_item_record,strlen(tb_item_record))!=strlen(tb_item_record)){
           exec_result=-1;  
      }
      tb_item=tb_item->tb_item_next;
   }
   return exec_result;        
}

void
tb_timer_handler(union sigval sig_val){
    struct TB_MANAGER_ST * volatile temp_t_ms;
    line_lock_st *lls;
    static int flag=0;
    static char * record_p;
    int exec_result_wtf,exec_result_uti,cur_record_fd,cur_tb_item_fd,cur_tb_fd;

    if(thr_cur_num>=thr_max/3*2)
        pthread_exit(NULL);

    if(flag==0){
       if((record_p=malloc(sizeof(tb_name_t)+15))==NULL){
           errExit("malloc for record_p failed!\n");
       }
       flag=1;
    }

    temp_t_ms=t_ms;
    printf("[save tms]:\n");
    
    cur_record_fd=tb_record_swap_flag?tb_record_swap_fd:tb_record_fd;
    
    if(!tb_record_swap_flag)
        if(rename("tb.record.swap.OK","tb.record.swap")==-1)
            errExit("to tb.record.swap failed [timer_handler]\n");
    else
        if(rename("tb.record.OK","tb.record")==-1)
            errExit("to tb.record failed [timer_handler]\n");
    
    if(ftruncate(cur_record_fd,0)!=0)
        errExit("truncate 0 failed!\n");
    lseek(cur_record_fd,SEEK_SET,0);

    read_lock(&dls.mtx,&dls.readcnt);
   
    while(temp_t_ms!=NULL){
        printf("\t%s:\n",temp_t_ms->tb_name);
        snprintf(record_p,sizeof(tb_name_t)+8,"%s:%d\n",temp_t_ms->tb_name,temp_t_ms->tb_line_size);
        write(cur_record_fd,record_p,strlen(record_p));
        if(temp_t_ms->tb_item_fd!=-1){
             cur_tb_item_fd=temp_t_ms->tb_item_swap_flag?temp_t_ms->tb_item_swap_fd:temp_t_ms->tb_item_fd;
             
             if(!temp_t_ms->tb_item_swap_flag){
                snprintf(path_buf,sizeof(path_buf),"%s/%s.item.swap.OK",temp_t_ms->tb_name,temp_t_ms->tb_name);
                snprintf(path_swap_buf,sizeof(path_buf),"%s/%s.item.swap",temp_t_ms->tb_name,temp_t_ms->tb_name);
                if(rename(path_buf,path_swap_buf)==-1)
                    errExit("to tb.item.swap failed [timer_handler]\n");
                      
             }else{
                snprintf(path_buf,sizeof(path_buf),"%s/%s.item.OK",temp_t_ms->tb_name,temp_t_ms->tb_name);
                snprintf(path_swap_buf,sizeof(path_buf),"%s/%s.item",temp_t_ms->tb_name,temp_t_ms->tb_name);
                if(rename(path_buf,path_swap_buf)==-1)
                    errExit("to tb.item failed [timer_handler]\n");
                      
             }

             if(ftruncate(cur_tb_item_fd,0)!=0)
                 printf("truncate 0 failed!\n");
             lseek(cur_tb_item_fd,SEEK_SET,0);
             exec_result_uti=update_tb_item(cur_tb_item_fd,temp_t_ms->tb_item_list);
             if(exec_result_uti==0){
                 if(!temp_t_ms->tb_item_swap_flag){
                      if(rename(path_swap_buf,path_buf)==-1)
                           errExit("to tb.item.swap.OK failed [timer_handler]\n");
                 }else{
                      if(rename(path_swap_buf,path_buf)==-1)
                            errExit("to tb.item.OK failed [timer_handler]\n");
                 }
                 temp_t_ms->tb_item_swap_flag=temp_t_ms->tb_item_swap_flag?0:1;
                 printf("\t\tupdate tb_item[success]\n");
             }else
                 errExit("\t\tupdate tb_item[failed]\n");
        }

        lls=temp_t_ms->tb_line_lock;
        if(!temp_t_ms->tb_swap_flag){
            snprintf(path_buf,sizeof(path_buf),"%s/%s.swap.OK",temp_t_ms->tb_name,temp_t_ms->tb_name);
            snprintf(path_swap_buf,sizeof(path_buf),"%s/%s.swap",temp_t_ms->tb_name,temp_t_ms->tb_name);
            if(rename(path_buf,path_swap_buf)==-1)
                errExit("to tb.swap failed [timer_handler]\n");
                      
        }else{
            snprintf(path_swap_buf,sizeof(path_buf),"%s/%s",temp_t_ms->tb_name,temp_t_ms->tb_name);
            snprintf(path_buf,sizeof(path_buf),"%s/%s.OK",temp_t_ms->tb_name,temp_t_ms->tb_name);
            if(rename(path_buf,path_swap_buf)==-1)
                errExit("to tb failed [timer_handler]\n");
        }
        cur_tb_fd=temp_t_ms->tb_swap_flag?temp_t_ms->tb_swap_fd:temp_t_ms->tb_fd;
        if(ftruncate(cur_tb_fd,0)!=0)
            printf("truncate 0 failed!\n");
        lseek(cur_tb_fd,SEEK_SET,0);
        while(lls!=NULL){
            if(!lls->isDeleted){
 //              read_lock(&lls->mtx,&lls->read_cnt);
               
               exec_result_wtf=tb_to_file(cur_tb_fd,temp_t_ms->tb_line_size,temp_t_ms->tb_addr);
               
//               read_unlock(&lls->mtx,&lls->cod,&lls->read_cnt);
            }
            if(exec_result_wtf!=0)
                break;
            lls=lls->line_lock_next;
        }
        if(exec_result_wtf==0){
            if(!temp_t_ms->tb_swap_flag){
                if(rename(path_swap_buf,path_buf)==-1)
                    errExit("to tb.swap.OK failed [timer_handler]\n");
                      
            }else{
                snprintf(path_swap_buf,sizeof(path_buf),"%s/%s",temp_t_ms->tb_name,temp_t_ms->tb_name);
                if(rename(path_swap_buf,path_buf)==-1)
                    errExit("to tb.OK failed [timer_handler]\n");
            }
            temp_t_ms->tb_swap_flag=temp_t_ms->tb_swap_flag?0:1;
            printf("\t\tupdate tb[success]\n");
        }
        else
            errExit("\t\tupdate tb [failed]\n");

        temp_t_ms=temp_t_ms->tb_manager_next;
    }
    read_unlock(&dls.mtx,&dls.cod,&dls.readcnt);
    
    if(!tb_record_swap_flag)
        if(rename("tb.record.swap","tb.record.swap.OK")==-1)
            errExit("to tb.record.swap.OK failed [timer_handler]\n");
    else
        if(rename("tb.record","tb.record.OK")==-1)
            errExit("to tb.record.OK failed [timer_handler]\n");
    tb_record_swap_flag=tb_record_swap_flag?0:1;
}

void tb_handler(db_manager_st dms){
    thr_manager_st * thr_ms,*temp_thr_ms;
    fs_pipe_ipc_st ipc_data;
    rep_head cl_response;
    int db_flag=1;

    if(chdir(dms.db_name)==-1)
        errExit("chdir error\n");
        
    if(init_tb_list(&t_ms)!=0)
        errExit("init_tb_list return nonzero!\n");
    if(init_thr_list(&thr_ms)!=0)
        errExit("init_thr_list return nonzero!\n");
    dls.readcnt=0;
    if(pthread_mutex_init(&dls.mtx,NULL)!=0)
        errExit("on dls.mtx\n");       
    if(pthread_cond_init(&dls.cod,NULL)!=0)
        errExit("on dls.cond\n");
    if(create_timer(int_timer,tb_timer_handler)!=0)
        errExit("create timer failed!\n");

    sleep(1);   //wo ye bu zhi dao wei shen me ,di yi ci fork shi,huan xing bu liao zi jin cheng, shui yi xia jiu hao le
    while(db_flag){
        if(recvmsg_(dms.unix_sock_fd[0],&ipc_msg,&ipc_data)==0){
            switch(ipc_data.event_type){
               case FS_TEST:
                   break;
               case FS_CONN:
                   temp_thr_ms=thr_ms;
                   while(temp_thr_ms!=NULL){
                       if(temp_thr_ms->cl_socket_fd!=0){
                           temp_thr_ms=temp_thr_ms->next; 
                           continue;
                       }
                       temp_thr_ms->cl_socket_fd=ipc_data.cl_socket;
                       printf("cl_socket:%d\n",temp_thr_ms->cl_socket_fd);
                       if(pthread_kill(temp_thr_ms->tid,SIGUSR2)!=0){
                           printf("pthread_kill error!\n");
                           rep_err(ipc_data.cl_socket,"something wrong occured!\n",&cl_response);
                           continue;
                       }
                       break;
                   }
                   if(temp_thr_ms==NULL){
                           rep_err(ipc_data.cl_socket,"reaches the connection limit!\n",&cl_response);
                           close(ipc_data.cl_socket);
                           continue;
                   }
                   rep_suc(ipc_data.cl_socket,&cl_response,0);
                   thr_cur_num++;
                   break;
               case FS_EXIT:
                   db_flag=0;
                   break;
               default:
                   printf("unknow FS type\n");
           }
       }else{
           _exit(1);     
       }

    }
}

static void
init_tb_item_list(struct TB_MANAGER_ST * tms){
    tb_item_st * tis,* temp_tis;
    int fd,setid_flag=-1;
    char * p1,*p2;
    
    snprintf(path_buf,sizeof(path_buf),"%s/%s.item.OK",tms->tb_name,tms->tb_name);
    snprintf(path_swap_buf,sizeof(path_buf),"%s/%s.item.swap.OK",tms->tb_name,tms->tb_name);
    
    tms->tb_item_swap_flag=0;
    if(access(path_buf,0)==0 && access(path_swap_buf,0)!=0){
         snprintf(path_buf,sizeof(path_buf),"%s/%s.item.swap",tms->tb_name,tms->tb_name);
         if(rename(path_buf,path_swap_buf)==-1)
              errExit("to tb.item.swap.OK rename failed\n");
         snprintf(path_buf,sizeof(path_buf),"%s/%s.item.OK",tms->tb_name,tms->tb_name);
        
     }else if(access(path_buf,0)!=0 && access(path_swap_buf,0)==0){
          snprintf(path_swap_buf,sizeof(path_buf),"%s/%s.item",tms->tb_name,tms->tb_name);
          if(rename(path_swap_buf,path_buf)==-1)
              errExit("to tb.item.swap.OK rename failed\n");
          tms->tb_item_swap_flag=1;
          snprintf(path_swap_buf,sizeof(path_buf),"%s/%s.item.swap.OK",tms->tb_name,tms->tb_name);
     }   
       
    tms->tb_item_fd=open(path_buf,O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
    if(tms->tb_item_fd==-1)
        errExit("tb_item_fd error!\n");
        
    tms->tb_item_swap_fd=open(path_swap_buf,O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
    if(tms->tb_item_swap_fd==-1)
        errExit("tb_item_swap_fd error!\n");
    fd=tms->tb_item_swap_flag?tms->tb_item_swap_fd:tms->tb_item_fd;
    
    tis=NULL;
    while(readline(fd,buf,TB_RECORD_LINE_SIZE-1)==0){
          if(buf[0]=='\0')
              continue;
          p1=buf;
          p2=buf+strlen(buf);
          while(p1!=p2){
             if(*p1!=':')
                 p1++;
             if(*p2!=':')
                 p2--;
             if(*p1==':' && *p2==':')
                 break;
          }
          if(p1==p2)
              errExit("parse line error!\n");
          *p1=*p2='\0';
          p1++;
          p2++;
          temp_tis=malloc(sizeof(tb_item_st));
          strncpy(temp_tis->tb_item_nm,buf,sizeof(tb_name_t));
          if((temp_tis->var_type=atoi(p1))<0)
              errExit("var_type atoi error!\n");
          if((temp_tis->relate_offset=atoi(p2))<0)         //in c , enum == int
              errExit("relate_offset atoi error!\n");
          temp_tis->tb_item_next=tis;
          tis=temp_tis;
          if(strcmp(temp_tis->tb_item_nm,"id")==0)
              setid_flag=1;
    }
    if(setid_flag==0){
          close(fd);
          close(tms->tb_item_swap_fd);
          tms->tb_item_fd=-1;
    }
    tms->tb_item_list=tis;
}

static line_lock_st *
init_tb_line_lock_list(void * tb_addr,int tb_line_size,int fd,int file_size){
    line_lock_st * lls, * temp_lls;
    void * temp_tb_addr;
    int numread=0;       //1:EOF 
    lls=NULL;
    temp_tb_addr=tb_addr;
    while((numread=read(fd,temp_tb_addr,tb_line_size))>0){  //EOF hao xiang ye hui bei du qu 
        if(numread!=tb_line_size)
           errExit("numread != tb_line_size!\n");
       temp_lls=malloc(sizeof(line_lock_st));
      
       temp_lls->read_cnt=0;
       temp_lls->isDeleted=FALSE;
       temp_lls->tb_line_p=temp_tb_addr;
       if(pthread_mutex_init(&temp_lls->mtx,NULL)!=0)         //remember pthread_mutex_destroy()
           errExit("init mutex error!\n");
       if(pthread_cond_init(&temp_lls->cod,NULL)!=0)
           errExit("init cond error!\n");

       temp_lls->line_lock_next=lls;
       lls=temp_lls;

       temp_tb_addr+=numread;
    }
    return lls;
}

int
init_tb_list(struct TB_MANAGER_ST * volatile * t_ms){    //ensure yi ji zhi zhen de ke jian xing
    char * p;
    tb_manager_st * temp_t_ms;
    struct stat  statbuf;
    int temp_fd;

    tb_record_swap_flag=0;
    if(access("tb.record.OK",0)==0 && access("tb.record.swap.OK",0)!=0){
        if(rename("tb.record.swap","tb.record.swap.OK")==-1)
            errExit("to tb.record.swap.OK rename failed\n");
    }else if(access("tb.record.OK",0)!=0 && access("tb.record.swap.OK",0)==0){
        if(rename("tb.record","tb.record.OK")==-1)
            errExit("to tb.record.OK rename failed\n");
        tb_record_swap_flag=1;
    }
               
    tb_record_fd=open("./tb.record.OK",O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
    if(tb_record_fd==-1)
        errExit("tb_record_fd error!\n");
    tb_record_swap_fd=open("./tb.record.swap.OK",O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
    if(tb_record_swap_fd==-1)
        errExit("tb_record_swap_fd error!\n");
    
    temp_fd=tb_record_swap_flag?tb_record_swap_fd:tb_record_fd;
    *t_ms=NULL;
    while(readline(temp_fd,buf,TB_RECORD_LINE_SIZE-1)==0){
        if(buf[0]=='\0')
            continue;
        p=buf;
        while(*p!='\0'){
           if(*p==':')
               break;
           p++;
        }
        if(*p=='\0')
           return -1 ;
        *p++='\0';
        printf("init1\n");
    
        if(strlen(buf)>=(sizeof(tb_name_t)-1))
            return -1;
        printf("2\n");
        temp_t_ms=malloc(sizeof(tb_manager_st));
        if(temp_t_ms==NULL)
            errExit("malloc for temp_t_ms failed!\n");
        if((temp_t_ms->tb_line_size=atoi(p))<=0)
            return -1;
        temp_t_ms->temp_item_p=malloc(temp_t_ms->tb_line_size);
        if(temp_t_ms->temp_item_p==NULL)
            errExit("malloc for temp_t_ms->temp_item_p failed!\n");

        printf("3\n");
        strcpy(temp_t_ms->tb_name,buf);
        
        snprintf(path_buf,sizeof(path_buf),"%s/%s.OK",temp_t_ms->tb_name,temp_t_ms->tb_name);
        snprintf(path_swap_buf,sizeof(path_buf),"%s/%s.swap.OK",temp_t_ms->tb_name,temp_t_ms->tb_name);
    
        temp_t_ms->tb_swap_flag=0;
        if(access(path_buf,0)==0 && access(path_swap_buf,0)!=0){
            snprintf(path_buf,sizeof(path_buf),"%s/%s.swap",temp_t_ms->tb_name,temp_t_ms->tb_name);
            if(rename(path_buf,path_swap_buf)==-1)
                errExit("to tb.swap.OK rename failed\n");
            snprintf(path_buf,sizeof(path_buf),"%s/%s.OK",temp_t_ms->tb_name,temp_t_ms->tb_name);
        
        }else if(access(path_buf,0)!=0 && access(path_swap_buf,0)==0){
            snprintf(path_swap_buf,sizeof(path_buf),"%s/%s",temp_t_ms->tb_name,temp_t_ms->tb_name);
            if(rename(path_swap_buf,path_buf)==-1)
                errExit("to tb.OK rename failed\n");
            temp_t_ms->tb_swap_flag=1;
        }   

        temp_t_ms->tb_fd=open(path_buf,O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
        if(temp_t_ms->tb_fd==-1)
            errExit("tb_record_fd error!\n");
        temp_t_ms->tb_swap_fd=open(path_swap_buf,O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
        if(temp_t_ms->tb_swap_fd==-1)
            errExit("tb_record_swap_fd error!\n");

        temp_fd=temp_t_ms->tb_swap_flag?temp_t_ms->tb_swap_fd:temp_t_ms->tb_fd;
        
        printf("4\n");
        if(fstat(temp_fd,&statbuf)==-1)
            return -1;
        printf("5\n");
        printf("filesize:%d\n",statbuf.st_size);
        if(statbuf.st_size % temp_t_ms->tb_line_size !=0 && statbuf.st_size!=0)       
                                                            //si hu EOL ye suan yi ge
            return -1;
        
        if(pthread_mutex_init(&temp_t_ms->mtx,NULL)!=0)     //remember pthread_mutex_destroy()
            errExit("init mutex error!\n");
        if(pthread_cond_init(&temp_t_ms->cod,NULL)!=0)
            errExit("init cond error!\n");
        temp_t_ms->tb_cur_size=statbuf.st_size;
        temp_t_ms->tb_max_size=statbuf.st_size<=TB_PRE_MIN_SIZE?TB_PRE_MIN_SIZE:statbuf.st_size * 2;
        temp_t_ms->tb_addr=malloc(temp_t_ms->tb_max_size);
        if(temp_t_ms->tb_addr==NULL)
            errExit("malloc for temp_t_ms->tb_addr!\n");

        temp_t_ms->tb_line_lock=init_tb_line_lock_list(temp_t_ms->tb_addr,temp_t_ms->tb_line_size,temp_fd,statbuf.st_size);

        temp_t_ms->tb_manager_next=*t_ms;
        *t_ms=temp_t_ms;
        tb_cur_num++;
    }

    while(temp_t_ms!=NULL){
        init_tb_item_list(temp_t_ms);
        if(temp_t_ms->tb_item_list==NULL){
           errExit("tb_item_list is NULL!\n");
        }
        temp_t_ms=temp_t_ms->tb_manager_next;
    }

    return 0;
}

static void
handler_exec_result(int flag,int cl_socket_fd,int data_len,rep_head * cl_response){
   switch(flag){
       case 0:
           printf("success!\n");
           rep_suc(cl_socket_fd,cl_response,data_len);
           break;
       case TE_READ:
           printf("TE_READ\n");
           rep_err(cl_socket_fd,"read error\n",cl_response);
           break;
       case TE_MALLOC:
           printf("TE_MALLOC\n");
           rep_err(cl_socket_fd,"malloc error!\n",cl_response);
           break;
       case TE_LEN:
           printf("TE_LEN\n");
           rep_err(cl_socket_fd,"data len error!\n",cl_response);
           break;
       case TE_CREFL:
           printf("TE_CREFL\n");
           rep_err(cl_socket_fd,"create file error!\n",cl_response);
           break;
       case TE_TYPE:
           printf("TE_TYPE\n");
           rep_err(cl_socket_fd,"data type error!\n",cl_response);
           break;
       case TE_WRTFL:
           printf("TE_WRTFL\n");
           rep_err(cl_socket_fd,"save to file error!\n",cl_response);
           break;
       case TE_CHNAME:
           printf("TE_CHNAME\n");
           rep_err(cl_socket_fd,"duplication of name error!\n",cl_response);
           break;
       case TE_DTEXIST:
           printf("TE_DTEXIST\n");
           rep_err(cl_socket_fd,"tb dont exist error!\n",cl_response);
           break;
       case TE_RECHLIM:
           printf("TE_RECHLIM\n");
           rep_err(cl_socket_fd,"reach the tb create limit  error!\n",cl_response);
           break;
       case TE_STLOST:
           printf("TE_STLOST\n");
           rep_err(cl_socket_fd,"the data of tb struct lost  error!\n",cl_response);
           break;
       case IE_DTEXIST:
           printf("IE_DTEXIST\n");
           rep_err(cl_socket_fd,"item is not exist  error!\n",cl_response);
           break;
       case IE_MEMLIM:
           printf("IE_MEMLIM\n");
           rep_err(cl_socket_fd,"reaches the memory limit  error!\n",cl_response);
           break;
       case IE_NONE:
           printf("IE_NONE\n");
           rep_err(cl_socket_fd,"no elibige  error!\n",cl_response);
           break;
       case IE_TRUNCFL:
           printf("IE_TRUNCFL\n");
           rep_err(cl_socket_fd,"truncate thr_ms->data_out_fd  failed!\n",cl_response);
           break;
       case IE_WRTFL:
           printf("IE_WRTFL\n");
           rep_err(cl_socket_fd,"item write to thr_ms->data_out_fd  failed!\n",cl_response);
           break;
       default:
           printf("UNKOWN ERROR\n");
           rep_err(cl_socket_fd,"unkown error!\n",cl_response);
   }
}


void *
connect_handler(void * arg){
    thr_manager_st * thr_ms;
    thr_ms=(thr_manager_st *)arg;
    req_head cl_request;
    rep_head cl_response;
    int numread=0,exec_result;
    struct timeval timeout={0,0};

    for(;;){
       pause();
       errno=0;
       while(1){
               numread=read(thr_ms->cl_socket_fd,&cl_request,sizeof(req_head));
               if(numread<=0){
                   close(thr_ms->cl_socket_fd);
                   printf("client close!\n");
                   break;
               }
               if(numread!=sizeof(req_head)){
                   rep_err(thr_ms->cl_socket_fd,"request error!\n",&cl_response);
                   continue;     
               }
               
               req_ntoh(&cl_request,sizeof(req_head));
               cl_request.op_type=cl_request.op_type;
               cl_request.rt_text=cl_request.rt_text;
               cl_request.len=cl_request.len;
               cl_request.tb_name[sizeof(tb_name_t)-1]='\0';
               switch(cl_request.op_type){
                   case CRE_TB:
                       write_lock(&dls.mtx,&dls.cod,&dls.readcnt);

                       printf("create tb:[%s]:",cl_request.tb_name);
                       if(is_tb_exist(cl_request.tb_name,t_ms)==0){
                           printf("tb has exist!\n");
                           rep_err(thr_ms->cl_socket_fd,"the tb has exist!\n",&cl_response);
                       }else{
                           if(tb_cur_num<tb_max_num){
                               exec_result= create_tb(thr_ms->cl_socket_fd,cl_request.len,TB_PRE_MAX_SIZE,cl_request.set_id,ITEM_MAX,cl_request.tb_name,&t_ms);
                               handler_exec_result(exec_result,thr_ms->cl_socket_fd,0,&cl_response);
                               if(exec_result==0)
                                   tb_cur_num++;
                           }else{
                               exec_result=TE_RECHLIM;
                               handler_exec_result(exec_result,thr_ms->cl_socket_fd,0,&cl_response);
                           }
                       }
                       write_unlock(&dls.mtx);
                       break;
                   case DEL_TB: 
                       write_lock(&dls.mtx,&dls.cod,&dls.readcnt);

                       printf("del_tb:[%s]:",cl_request.tb_name);
                       exec_result=delete_tb(cl_request.tb_name,&t_ms);
                       handler_exec_result(exec_result,thr_ms->cl_socket_fd,0,&cl_response);
                       if(exec_result==0)
                           tb_cur_num--;
                      
                       write_unlock(&dls.mtx);
                       break;
                   case TRUNC_TB:
                       write_lock(&dls.mtx,&dls.cod,&dls.readcnt);
                      
                       printf("trunc_tb:[%s]:",cl_request.tb_name);
                       exec_result=trunc_tb(cl_request.tb_name,t_ms);
                       handler_exec_result(exec_result,thr_ms->cl_socket_fd,0,&cl_response);
                       
                       write_unlock(&dls.mtx);
                       break;
                   case DEL_ITEM:
                       read_lock(&dls.mtx,&dls.readcnt);
                       
                       printf("del_item:[%s]:",cl_request.tb_name);
                       exec_result=delete_item(thr_ms->cl_socket_fd,cl_request.len,ITEM_MAX,cl_request.tb_name,t_ms);
                       handler_exec_result(exec_result,thr_ms->cl_socket_fd,0,&cl_response);

                       read_unlock(&dls.mtx,&dls.cod,&dls.readcnt);
                       break;
                   case ADD_ITEM:
                       read_lock(&dls.mtx,&dls.readcnt);
                      
                       printf("add_item\n");
                       exec_result=add_item(thr_ms->cl_socket_fd,cl_request.len,ITEM_MAX,TB_PRE_MAX_SIZE,cl_request.tb_name,t_ms);
                       handler_exec_result(exec_result,thr_ms->cl_socket_fd,0,&cl_response);

                       read_unlock(&dls.mtx,&dls.cod,&dls.readcnt);
                       break;
                   case MOD_ITEM:
                       read_lock(&dls.mtx,&dls.readcnt);

                       printf("mod_item\n");
                       exec_result=modify_item(thr_ms->cl_socket_fd,cl_request.len,cl_request.mod_len,ITEM_MAX,cl_request.tb_name,t_ms);
                       handler_exec_result(exec_result,thr_ms->cl_socket_fd,0,&cl_response);


                       read_unlock(&dls.mtx,&dls.cod,&dls.readcnt);
                       break;
                   case QUE_ITEM:
                       read_lock(&dls.mtx,&dls.readcnt);

                       printf("que_item\n");
                       exec_result=query_item(thr_ms->cl_socket_fd,thr_ms->data_out_fd,cl_request.len,ITEM_MAX,cl_request.rt_text,cl_request.tb_name,t_ms);
                       handler_exec_result(exec_result>=0?exec_result:0,thr_ms->cl_socket_fd,exec_result>=0?0:-exec_result,&cl_response);
                       
                       read_unlock(&dls.mtx,&dls.cod,&dls.readcnt);

                       if(exec_result<0){
                           lseek(thr_ms->data_out_fd,0,SEEK_SET);     
                           if(sendfile(thr_ms->cl_socket_fd,thr_ms->data_out_fd,NULL,(-exec_result)*t_ms->tb_line_size)!=(-exec_result)*t_ms->tb_line_size){
                               close(thr_ms->cl_socket_fd);
                               printf("sendfile failed!\n");     
                           }
                       }

                       break;
                   default:
                        rep_err(thr_ms->cl_socket_fd,"unkown request !\n",&cl_response);
               }
       }
       thr_ms->cl_socket_fd=0;
       thr_cur_num--;
    }
}

static void
thr_sig_handler(int sig){
}

int
init_thr_list(thr_manager_st ** thr_ms){
    struct sigaction sa;
    thr_manager_st * temp_thr_ms;
    int i=1;
    FILE * data_out_FILES;

    sa.sa_handler=thr_sig_handler;
    sa.sa_flags=SA_RESTART;
    sigemptyset(&sa.sa_mask);
    if(sigaction(SIGUSR2,&sa,NULL)==-1)
        errExit("sigcation error!\n");
    
    *thr_ms=NULL;
    while(i++<=thr_max){
       temp_thr_ms=malloc(sizeof(thr_manager_st));
       temp_thr_ms->cl_socket_fd=0;
       data_out_FILES=tmpfile();

       if(data_out_FILES==NULL)
           errExit("create temp file failed!\n");
       if((temp_thr_ms->data_out_fd=fileno(data_out_FILES))==-1)
           errExit("transform FILE * to fd failed!\n");

       if(pthread_create(&temp_thr_ms->tid,NULL,connect_handler,temp_thr_ms)!=0)
           errExit("create pthread error!\n");
       temp_thr_ms->next=*thr_ms;
       *thr_ms=temp_thr_ms;
    }
    if(*thr_ms==NULL)
        return -1;
    return 0;
}





