#ifndef DB_MANAGER_H
#define DB_MANAGER_H
#include<signal.h>
#include<time.h>
#include"./libcommon/db.inc.c"
#include"../../lib/tlpi_hdr.h"
#include<pthread.h>
#include<fcntl.h>
#include<unistd.h>
#include<sys/stat.h>
#include<stdlib.h>
#include<sys/socket.h>
#include<sys/sendfile.h>

typedef struct TB_ITEM_ST{
   Var_T var_type;
   tb_name_t tb_item_nm;
   volatile int relate_offset;
   struct TB_ITEM_ST * tb_item_next;
}tb_item_st;

typedef struct LINE_LOCK_ST{
   volatile int read_cnt;
   volatile Boolean isDeleted;
   pthread_mutex_t mtx;
   pthread_cond_t cod;
   void * tb_line_p;
   struct LINE_LOCK_ST * line_lock_next;
}line_lock_st;

typedef struct{
   volatile int readcnt;
   pthread_mutex_t mtx;
   pthread_cond_t cod;
}db_lock_st;

typedef struct TB_MANAGER_ST{
   int tb_line_size;
   int tb_fd;
   int tb_swap_fd;
   int tb_swap_flag;
   int tb_item_fd;
   int tb_item_swap_fd;
   int tb_item_swap_flag;
   
   volatile int tb_max_size;             //real size * 2 || > 8192
   volatile int tb_cur_size;

   pthread_mutex_t mtx;
   pthread_cond_t cod;
   tb_name_t tb_name;
   void * temp_item_p;
   void * volatile tb_addr;
   line_lock_st * volatile tb_line_lock;
   tb_item_st * volatile tb_item_list;
   struct TB_MANAGER_ST * volatile tb_manager_next;
}tb_manager_st;

typedef struct DB_MANAGER_ST{
   Boolean isOpenned;
   Boolean isDeleted;
   int unix_sock_fd[2];
   db_name_t db_name;
   chr_25_t passwd;
   struct DB_MANAGER_ST * db_manager_next;
}db_manager_st;

typedef struct THR_MANAGER_ST {
   pthread_t tid;
   int data_out_fd;
   volatile int cl_socket_fd;              //-1 means the thread is idle.

   struct THR_MANAGER_ST * next; 
}thr_manager_st;

typedef struct {
   Fs_T  event_type;
   int cl_socket;
}fs_pipe_ipc_st;

extern int readline(int,char *,int);
extern int db_create(char *,char *,db_manager_st **);
extern int check_passwd(chr_25_t,char *);
extern int db_delete(char * ,char *,db_manager_st **);
extern int rep_err(int ,char * ,rep_head *);
extern int rep_suc(int ,rep_head * ,int);
extern void tb_handler(db_manager_st );
extern int create_timer(int,void (*)(union sigval ));
extern int sendmsg_func(int,fs_pipe_ipc_st * ,struct msghdr *);
extern int recvmsg_func(int ,struct msghdr * ,fs_pipe_ipc_st * ip_data);
extern int create_tb(int ,int , int , int ,int ,tb_name_t , struct TB_MANAGER_ST * volatile *);
extern int is_tb_exist(tb_name_t ,struct TB_MANAGER_ST * volatile );
extern void req_ntoh(void * ,int);
extern long ntohl_(long);
extern long htonl_(long);
extern int realloc_tb(struct TB_MANAGER_ST * volatile ,int);
extern int trunc_tb(tb_name_t , struct TB_MANAGER_ST * volatile );
extern int delete_tb(tb_name_t , struct TB_MANAGER_ST * volatile *);
extern void read_lock(pthread_mutex_t * ,volatile int *);
extern void read_unlock(pthread_mutex_t *,pthread_cond_t * ,volatile int *);
extern void write_lock(pthread_mutex_t *, pthread_cond_t * ,volatile int *);
extern void write_unlock(pthread_mutex_t *);
extern int add_item(int ,int ,int ,int ,tb_name_t ,struct TB_MANAGER_ST *);
extern int query_item(int ,int ,int ,int  ,int ,tb_name_t ,struct TB_MANAGER_ST * volatile);
extern int delete_item(int ,int ,int ,tb_name_t ,struct TB_MANAGER_ST * volatile);
extern int modify_item(int,int,int,int,tb_name_t,struct TB_MANAGER_ST * volatile);
#endif
