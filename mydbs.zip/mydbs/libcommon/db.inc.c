#pragma pack(8)
typedef enum{
   GE,LE,NE,EQ,GT,LT,ALL        
}Logical_T;
typedef enum{
   CRE_DB,OPE_DB,DEL_DB,CRE_TB,DEL_TB,TRUNC_TB,DEL_ITEM,ADD_ITEM,MOD_ITEM,QUE_ITEM        
}Operation_T;

typedef enum{
   FAILED,SUCCESS        
}Response_T;

typedef enum{
   CHAR_25,CHAR_255,SHT,U_INT,INT,LONG        
}Var_T;

typedef enum{
   FS_TEST,FS_CONN,FS_EXIT        
}Fs_T;

typedef enum{
   TE_READ=1,TE_MALLOC,TE_LEN,TE_CREFL,TE_TYPE,TE_WRTFL,TE_CHNAME,TE_DTEXIST,TE_RECHLIM,TE_STLOST,IE_DTEXIST,IE_MEMLIM,IE_NONE,IE_TRUNCFL,IE_WRTFL        
}TBError_T;

typedef char db_name_t[25];
typedef char tb_name_t[25];

typedef unsigned int id_t;
typedef char chr_25_t[25];
typedef char chr_255_t[255];

typedef struct{
  Operation_T op_type;
  int len;
  int mod_len;
  int rt_text;
  int rt_limit;
  int set_id;
  db_name_t db_name;
  tb_name_t tb_name;
}req_head;
typedef struct{
  Response_T rep_type;
  int len;
  char rep_descript[50];
}rep_head;

typedef struct REQ_MOD_ST{
   chr_25_t col_nm;
   chr_255_t row_vl;
   struct REQ_MOD_ST * next;
}req_mod_st;

typedef  struct REQ_DATA_ST{ 
  Logical_T lo_type;
  Var_T var_type;
  chr_25_t col_nm;
  chr_255_t row_vl;
  struct QUERY_ST * next;
}req_data_st;
