#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <netdb.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include"./libcommon/db.inc.c"

struct test{
   short a;
   long b;
   short c;
   chr_25_t d;
};

short a;
long test_l=0x0807060504030201;
char * test_l_p;

static long
ntohl_(long hl_){
   short a=1,i=0,mid;
   unsigned char * rt_hl;

   if((char*)&a==0)
       return hl_;

   mid=sizeof(long)/2;
   rt_hl=(unsigned char *)&hl_;
   for(;i<4;i++){
       rt_hl[i]=rt_hl[i]^rt_hl[sizeof(long)-1-i];
       rt_hl[sizeof(long)-1-i]=rt_hl[i]^rt_hl[sizeof(long)-1-i];
       rt_hl[i]=rt_hl[i]^rt_hl[sizeof(long)-1-i];

   }
   return *(long *)rt_hl;
}

void
req_hton(void * req_st,int st_len){
    req_head *cl_req_head;
    req_data_st *cl_req_data;

    if(st_len==sizeof(req_head)){
        cl_req_head=req_st;
        cl_req_head->op_type=htonl(cl_req_head->op_type);
        cl_req_head->len=htonl(cl_req_head->len);
        cl_req_head->rt_text=htonl(cl_req_head->rt_text);
        cl_req_head->rt_limit=htonl(cl_req_head->rt_limit);
        cl_req_head->set_id=htonl(cl_req_head->set_id);
        cl_req_head->mod_len=htonl(cl_req_head->mod_len);
               
    }
    else if(st_len==sizeof(req_data_st)){
        cl_req_data=req_st;
        cl_req_data->lo_type=htonl(cl_req_data->lo_type);       
        cl_req_data->var_type=htonl(cl_req_data->var_type);       
    }
}

int main(int argc,char *argv[])
{
  req_head cl_req_head; 
  req_data_st cl_req_data;
  rep_head cl_rep_head;
  int sockfd,numbytes;
  char buf[BUFSIZ];
  struct sockaddr_in their_addr;

  cl_req_head.op_type=CRE_DB;
  strcpy(cl_req_head.db_name,"test5");
  cl_req_head.len=0;
 
  a=1;
  test_l_p=(char*)&test_l;


  printf("before: %0x %0x %0x %0x %0x %0x %0x %0x \n",test_l_p[0],test_l_p[1],test_l_p[2],test_l_p[3],test_l_p[4],test_l_p[5],test_l_p[6],test_l_p[7]); 
  test_l=ntohl_(test_l);
  printf("after: %0x %0x %0x %0x %0x %0x %0x %0x \n",test_l_p[0],test_l_p[1],test_l_p[2],test_l_p[3],test_l_p[4],test_l_p[5],test_l_p[6],test_l_p[7]); 
  printf(",%s\n",(char * )&a==0?"Big":"SMALL");
  printf("struct test size:%d\n",sizeof(struct test));
  
  printf("break!");
  while((sockfd = socket(AF_INET,SOCK_STREAM,0)) == -1);
  printf("We get the sockfd~\n");
  their_addr.sin_family = AF_INET;
  their_addr.sin_port = htons(9999);
  their_addr.sin_addr.s_addr=inet_addr("192.168.147.131");
  bzero(&(their_addr.sin_zero), 8);
                       
  while(connect(sockfd,(struct sockaddr*)&their_addr,sizeof(struct sockaddr)) == -1);

  printf("Get the Server~Cheers!\n");
/*
  numbytes = send(sockfd, &cl_req_head, sizeof(cl_req_head), 0);
  numbytes=recv(sockfd,&cl_rep_head,sizeof(rep_head),0);  
  printf("received:%s\n",cl_rep_head.rep_descript);  

  cl_req_head.op_type=DEL_DB;
  numbytes = send(sockfd, &cl_req_head, sizeof(cl_req_head), 0);
  numbytes=recv(sockfd,&cl_rep_head,sizeof(rep_head),0);  
  printf("received:%s\n",cl_rep_head.rep_descript);  


  cl_req_head.op_type=DEL_DB;
  strcpy(cl_req_head.db_name,"test4");
  numbytes = send(sockfd, &cl_req_head, sizeof(cl_req_head), 0);
  numbytes=recv(sockfd,&cl_rep_head,sizeof(rep_head),0);  
  printf("received:%s\n",cl_rep_head.rep_descript);  
*/
  cl_req_head.op_type=OPE_DB;
  strcpy(cl_req_head.db_name,"test5");
  strcpy(cl_req_head.tb_name,"abc");
  req_hton(&cl_req_head,sizeof(req_head));
  numbytes = send(sockfd, &cl_req_head, sizeof(cl_req_head), 0);
  numbytes=recv(sockfd,&cl_rep_head,sizeof(rep_head),0);  
  printf("received:%s\n",cl_rep_head.rep_descript);  
  printf("errno:%d\n",errno);
 
  cl_req_head.op_type=MOD_ITEM;
  strcpy(cl_req_head.tb_name,"test4");
  cl_req_head.len=3;
  cl_req_head.mod_len=1;
  cl_req_head.set_id=1;
  req_hton(&cl_req_head,sizeof(req_head));
  numbytes = send(sockfd, &cl_req_head, sizeof(cl_req_head), 0);

  cl_req_data.var_type=SHT;
  strcpy(cl_req_data.col_nm,"test1");
  cl_req_data.row_vl[0]='a';
  req_hton(&cl_req_data,sizeof(req_data_st));
  numbytes = send(sockfd, &cl_req_data, sizeof(cl_req_data), 0);
  
  cl_req_data.var_type=LONG;
  strcpy(cl_req_data.col_nm,"test3");
  req_hton(&cl_req_data,sizeof(req_data_st));
  numbytes = send(sockfd, &cl_req_data, sizeof(cl_req_data), 0);
 
  cl_req_data.var_type=SHT;
  strcpy(cl_req_data.col_nm,"test2");
  req_hton(&cl_req_data,sizeof(req_data_st));
  numbytes = send(sockfd, &cl_req_data, sizeof(cl_req_data), 0);
  numbytes=recv(sockfd,&cl_rep_head,sizeof(rep_head),0); 

  printf("received:%s\n",cl_rep_head.rep_descript);  

  close(sockfd);
 return 0;
}

