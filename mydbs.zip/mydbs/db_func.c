#define _POSIX_C_SOURCE 199309
#define _GNU_SOURCE
#define _XOPEN_SOURCE 500
#include<ftw.h>
#include<pthread.h>
#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/stat.h>
#include"./db_manager.h"
#include<signal.h>
#include<time.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<dirent.h>

#define RDL_BUF_SIZE   255
#define CONTROLLEN CMSG_LEN((sizeof(int)))
#ifndef DB_PREX 
#define DB_PREX "db_"
#endif

static __thread char *  unreadbuf_=NULL;
static __thread int unrdbuf_index=0;
static __thread int init_flag=0;
static __thread int numread=0;
static __thread int unrdbuf_l=0;

static __thread long * lls_search_set;
static __thread int lls_search_set_len=0;
static __thread req_mod_st * rms_list=NULL;
static __thread int rms_list_flag=0;

int
readline(int fd,char * buf,int length){
    int cnt=0;

    if(init_flag==0){
       unrdbuf_l=RDL_BUF_SIZE>length?RDL_BUF_SIZE:length;
       unreadbuf_=malloc(unrdbuf_l);
       if(unreadbuf_==NULL){
           printf("readline: malloc error!\n");
           return -1;
       }
       init_flag=1;
    }
    
    for(;;){
        while(unrdbuf_index<numread){
           if(cnt>=length){
                 buf[cnt]='\0';
                 return 0;
            }
           if(unreadbuf_[unrdbuf_index]!='\n' ){
               if(unreadbuf_[unrdbuf_index]!='\0')
                 buf[cnt++]=unreadbuf_[unrdbuf_index++];    
               else
                   unrdbuf_index++;
            }else{
                 unrdbuf_index++;
                 buf[cnt]='\0';
                 return 0;               
             }
        }
    if((numread=read(fd,(void *)unreadbuf_,unrdbuf_l-1))>0){
         unrdbuf_index=0;
    }else if(numread==0){
       unrdbuf_index=0;
       numread=0;
       buf[cnt]='\0';
       return 1;        
    }
    else {
       unrdbuf_index=0;
       numread=0;
       return -1;
    }
  }
}

int
db_create(char * o_db_name,char * cl_pw,db_manager_st ** dms){        //-1 error, 0 success, 1  exist.
    //1.check whether exist!
    int dir_len=sizeof((*dms)->db_name)+3;
    char * dir;
    db_manager_st * temp_dms;
    db_name_t db_name;
    snprintf(db_name,sizeof(db_manager_st),"%s%s",DB_PREX,o_db_name);

    temp_dms=*dms;
    while(temp_dms!=NULL){
       if(strcmp(db_name,temp_dms->db_name)==0)
           return 1;
       temp_dms=temp_dms->db_manager_next;
    }

    dir=malloc(dir_len);
    snprintf(dir,dir_len,"%s%s","./",db_name);
    if(mkdir(dir,S_IRUSR |S_IWUSR | S_IXUSR)==-1)
        return -1;
    temp_dms=malloc(sizeof(db_manager_st));
    //temp_dms->isOpenned=FALSE;
    strcpy(temp_dms->passwd,cl_pw);
    temp_dms->isDeleted=FALSE;
    strcpy(temp_dms->db_name,db_name);
    temp_dms->db_manager_next=*dms;
    *dms=temp_dms;
    
    free(dir);
    return 0;
}

int
check_passwd(chr_25_t tb_pw,char * cl_pw){
    if(strcmp(tb_pw,cl_pw)==0 || strcmp(tb_pw,"none")==0)
        return 1;
    return 0;
}

int del_dir(const char * pathname){
    DIR*  dir_stream;
    struct dirent * dt;
    struct stat statbuf;
    char path_buf[100];

    if((dir_stream=opendir(pathname))==NULL)
        return -1;
    while((dt=readdir(dir_stream))!=NULL){
       snprintf(path_buf,100,"%s/%s",pathname,dt->d_name);
       if(strcmp(dt->d_name,".")==0 || strcmp(dt->d_name,"..")==0)
           continue;

       else if(stat(path_buf,&statbuf)!=-1){
           if(S_ISDIR(statbuf.st_mode)){
               del_dir(path_buf);
           }else if(S_ISREG(statbuf.st_mode)){
               unlink(path_buf);     
           }else{
               printf("unkown type file!\n");
           }
       }else{
           printf("stat failed!\n");     
       }
    }
    closedir(dir_stream);
    if(rmdir(pathname)==-1){
         printf("del %s failed\n",pathname);
         return -1;    
    }
    return 0;
}

int
db_delete(char * o_db_name,char * cl_pw,db_manager_st ** dms){
    db_manager_st * temp_dms,* dms_pre;
    db_name_t db_name;
    fs_pipe_ipc_st ipc_data;
    
    snprintf(db_name,sizeof(db_manager_st),"%s%s",DB_PREX,o_db_name);
    temp_dms=*dms;
    dms_pre=*dms;
    while(temp_dms!=NULL){
       if(strcmp(temp_dms->db_name,db_name)==0 )
           break;
       dms_pre=temp_dms;
       temp_dms=temp_dms->db_manager_next;
    }
    if(temp_dms==NULL)
        return 1;

    if(check_passwd(temp_dms->passwd,cl_pw)==0)
        return -2;

    if(temp_dms==*dms){
        *dms=(*dms)->db_manager_next;       
    }else
        dms_pre->db_manager_next=temp_dms->db_manager_next;

    if(temp_dms->isOpenned==TRUE){
       ipc_data.event_type=FS_EXIT;
       if(write(temp_dms->unix_sock_fd[1],&ipc_data,sizeof(fs_pipe_ipc_st))==-1)
           return -1;
    }
    close(temp_dms->unix_sock_fd[1]);
    free(temp_dms);
    if(del_dir(db_name)==-1){
       printf("remove db:%s failed!\n",db_name);
       return -1;        
    }
    return 0;
}

void
req_ntoh(void * req_st,int st_len){
    req_head *cl_req_head;
    req_data_st *cl_req_data;

    if(st_len==sizeof(req_head)){
        cl_req_head=req_st;
        cl_req_head->op_type=ntohl(cl_req_head->op_type);
        cl_req_head->len=ntohl(cl_req_head->len);
        cl_req_head->rt_text=ntohl(cl_req_head->rt_text);
        cl_req_head->rt_limit=ntohl(cl_req_head->rt_limit);
        cl_req_head->set_id=ntohl(cl_req_head->set_id);
        cl_req_head->mod_len=ntohl(cl_req_head->mod_len);
               
    }
    else if(st_len==sizeof(req_data_st)){
        cl_req_data=req_st;
        cl_req_data->lo_type=ntohl(cl_req_data->lo_type);       
        cl_req_data->var_type=ntohl(cl_req_data->var_type);       
    }
}

long
ntohl_(long nl_){
   short a=1,i=0,mid;
   unsigned char * rt_hl;

   if((char*)&a==0)
       return nl_;

   mid=sizeof(long)/2;
   rt_hl=(unsigned char *)&nl_;
   for(;i<4;i++){
       rt_hl[i]=rt_hl[i]^rt_hl[sizeof(long)-1-i];
       rt_hl[sizeof(long)-1-i]=rt_hl[i]^rt_hl[sizeof(long)-1-i];
       rt_hl[i]=rt_hl[i]^rt_hl[sizeof(long)-1-i];

   }
   return *(long *)rt_hl;
}

long
htonl_(long hl_){
   short a=1,i=0,mid;
   unsigned char * rt_nl;

   if((char*)&a==0)
       return hl_;

   mid=sizeof(long)/2;
   rt_nl=(unsigned char *)&hl_;
   for(;i<4;i++){
       rt_nl[i]=rt_nl[i]^rt_nl[sizeof(long)-1-i];
       rt_nl[sizeof(long)-1-i]=rt_nl[i]^rt_nl[sizeof(long)-1-i];
       rt_nl[i]=rt_nl[i]^rt_nl[sizeof(long)-1-i];

   }
   return *(long *)rt_nl;
}

int
rep_err(int cl_socket_fd,char * descript,rep_head * err_response){
   memset(err_response,0,sizeof(err_response));
   err_response->rep_type=FAILED;
   strncpy(err_response->rep_descript,descript,sizeof(err_response->rep_descript)-1);
   err_response->rep_descript[sizeof(err_response->rep_descript)-1]='\0';
   write(cl_socket_fd,err_response,sizeof(rep_head));
}
int 
rep_suc(int cl_socket_fd,rep_head * suc_response,int len){
   memset(suc_response,0,sizeof(suc_response));
   suc_response->rep_type=SUCCESS;
   suc_response->rep_type=htonl(suc_response->rep_type);
   suc_response->len=htonl(len);
   suc_response->rep_descript[0]='\0';
   write(cl_socket_fd,suc_response,sizeof(rep_head));
}


int
create_timer(int timer_interval,void (*timer_handler)(union sigval)){
   timer_t timerid;
   struct sigevent evp;
   struct itimerspec ts;
   
   evp.sigev_notify=SIGEV_THREAD;
   evp.sigev_notify_function=timer_handler;
   evp.sigev_notify_attributes=NULL;
   evp.sigev_value.sival_int=0;

   if(timer_create(CLOCK_REALTIME,&evp,&timerid)==-1)
       return -1;
   ts.it_interval.tv_sec=timer_interval;
   ts.it_interval.tv_nsec=0;
   ts.it_value.tv_sec=timer_interval;
   ts.it_value.tv_nsec=0;
   if(timer_settime(timerid,0,&ts,NULL)==-1)
       return -1;
   return 0;
}

int
sendmsg_(int sockfd,fs_pipe_ipc_st * ipc_data_p,struct msghdr * msgptr){
   static int flag=0;
   static  struct cmsghdr * cmsgptr;
   Fs_T event_type;
   struct iovec iov;

   memset(msgptr,0,sizeof(struct msghdr));

   if(flag==0){
       if((cmsgptr=malloc(CONTROLLEN))==NULL)
           return -1;
       flag=1;
   }
   msgptr->msg_name=NULL;
   msgptr->msg_namelen=0;
   event_type=ipc_data_p->event_type;
   iov.iov_base=&event_type;
   iov.iov_len=sizeof(Fs_T);
   msgptr->msg_iov=&iov;
   msgptr->msg_iovlen=1;


   if(ipc_data_p->event_type==FS_CONN){
      cmsgptr->cmsg_level=SOL_SOCKET;
      cmsgptr->cmsg_type=SCM_RIGHTS;
      cmsgptr->cmsg_len=CONTROLLEN;
      msgptr->msg_control=cmsgptr;
      msgptr->msg_controllen=CONTROLLEN;
      *(int *)CMSG_DATA(cmsgptr)=ipc_data_p->cl_socket;
   }
   if(sendmsg(sockfd,msgptr,0)!=sizeof(Fs_T))
       return -1;
   return 0;
}

int 
recvmsg_(int sockfd,struct msghdr * msgptr,fs_pipe_ipc_st * ipc_data){
   static int flag=0;      
   static struct cmsghdr * cmsgptr;
   struct iovec iov;

   memset(msgptr,0,sizeof(struct msghdr));

   if(flag==0){
       if((cmsgptr=malloc(CONTROLLEN))==NULL)
           return -1;
       flag=1;
   }
   msgptr->msg_name=NULL;
   msgptr->msg_namelen=0;
   iov.iov_base=&ipc_data->event_type;
   iov.iov_len=sizeof(Fs_T);
   msgptr->msg_iov=&iov;
   msgptr->msg_iovlen=1;
   msgptr->msg_control=cmsgptr;
   msgptr->msg_controllen=CONTROLLEN;
   if(recvmsg(sockfd,msgptr,0)<=0)
       return -1;
   if(ipc_data->event_type==FS_CONN){
       if(msgptr->msg_controllen<CONTROLLEN)
           return -1;
       ipc_data->cl_socket=*(int *)CMSG_DATA(cmsgptr);     
   }
   return 0;
}

int   //0 on true,1 on false
is_tb_exist(tb_name_t tb_name,struct TB_MANAGER_ST * volatile  tms_p){
     while(tms_p!=NULL){
         if(strcmp(tb_name,tms_p->tb_name)==0)
             return 0;
         tms_p=tms_p->tb_manager_next;
     }
     return 1;
}

void
read_lock(pthread_mutex_t * mtx,volatile int * readcnt){
     if(pthread_mutex_lock(mtx)!=0)
          errExit("read_lock lock error!\n");
     ++(*readcnt);
     if(pthread_mutex_unlock(mtx)!=0)
          errExit("read_lock unlock error!\n");
}

void
read_unlock(pthread_mutex_t * mtx ,pthread_cond_t * cod ,volatile int * readcnt){
     if(pthread_mutex_lock(mtx)!=0)
          errExit("read_unlock lock error!\n");
     --(*readcnt);
     if(*readcnt==0)
          if(pthread_cond_broadcast(cod)!=0)
               errExit("read_unlock broadcast error!\n");
     if(pthread_mutex_unlock(mtx)!=0)
          errExit("read_unlock unlock error!\n");
}

void
write_lock(pthread_mutex_t * mtx ,pthread_cond_t * cod ,volatile int * readcnt){
    if(pthread_mutex_lock(mtx)!=0){
         errExit("write_lock lock error!\n");
     }
     while(*readcnt!=0)
         if(pthread_cond_wait(cod,mtx)!=0)
               errExit("write_lock wait error!\n");
}

void
write_unlock(pthread_mutex_t * mtx){
     if(pthread_mutex_unlock(mtx)!=0)
         errExit("write_unlock error!\n");
}

static void *  
reuse_deleted_item(line_lock_st * lls){   //if memory is not enough,reuse deleted item.
   while(lls!=NULL){
       if(lls->isDeleted==TRUE){
           printf("1 check lock\n");
           write_lock(&lls->mtx,&lls->cod,&lls->read_cnt);
           if(lls->isDeleted==TRUE){
               lls->read_cnt=0;
               return lls;
           }else
               write_unlock(&lls->mtx);
       }
       lls=lls->line_lock_next;
   }
   return NULL;
}

int
realloc_tb(struct TB_MANAGER_ST *volatile tms,int limit){
    void * temp_ptr;

    if(tms->tb_max_size*2>limit)
         return 1;
     pthread_mutex_lock(&tms->mtx);
     if(tms->tb_line_size+tms->tb_cur_size<tms->tb_max_size){
         pthread_mutex_unlock(&tms->mtx);
         return 0;
     }
     tms->tb_max_size=2*tms->tb_max_size;
     if((temp_ptr=realloc(tms->tb_addr,tms->tb_max_size))==NULL){
         pthread_mutex_unlock(&tms->mtx);
         return -1;
              
     }else{
         tms->tb_addr=temp_ptr;       
     }
     pthread_mutex_unlock(&tms->mtx);
     return 0;
}

static int 
free_tms(struct TB_MANAGER_ST * tms,int cl_fl_flag){
     line_lock_st *tb_line_lock;
     tb_item_st * tb_item_list;
    
     tb_line_lock=tms->tb_line_lock;
     while(tb_line_lock!=NULL){
          tb_line_lock=tms->tb_line_lock->line_lock_next;
          if(pthread_mutex_destroy(&tms->tb_line_lock->mtx)!=0)
              return -1;
          if(pthread_cond_destroy(&tms->tb_line_lock->cod)!=0)
              return -1;;
          free(tms->tb_line_lock);
          tms->tb_line_lock=tb_line_lock;
     }
     if(cl_fl_flag){
         close(tms->tb_fd);
         close(tms->tb_item_fd);
         free(tms->tb_addr);
         if(pthread_mutex_destroy(&tms->mtx)!=0)
             return -1;
         if(pthread_cond_destroy(&tms->cod)!=0)
             return -1;;
        
         tb_item_list=tms->tb_item_list;
         while(tms->tb_item_list!=NULL){
            tb_item_list=tms->tb_item_list;
            tms->tb_item_list=tms->tb_item_list->tb_item_next;
            free(tb_item_list);
        }
        free(tms);
     }else if(tms->tb_item_fd!=-1){
         tb_item_list=tms->tb_item_list;
         while(tb_item_list!=NULL){
            if(strcmp(tb_item_list->tb_item_nm,"id")==0){
                tb_item_list->relate_offset=0;
                break;
            }
            tb_item_list=tb_item_list->tb_item_next;
         }
              
     }
     printf("free tb success!\n");
     return 0;
}

int
delete_tb(tb_name_t tb_name,struct TB_MANAGER_ST * volatile * tms_p){
     struct TB_MANAGER_ST * temp_tms_p,* temp_tms_c;
     
     temp_tms_p=temp_tms_c=*tms_p;
     while(temp_tms_c!=NULL){
        if(strcmp(temp_tms_c->tb_name,tb_name)==0){
           if(temp_tms_c==*tms_p)
               *tms_p=(*tms_p)->tb_manager_next;
           else
               temp_tms_p->tb_manager_next=temp_tms_c->tb_manager_next;

           return free_tms(temp_tms_c,1);
        }
        temp_tms_p=temp_tms_c;
        temp_tms_c=temp_tms_c->tb_manager_next;
     }
     return TE_DTEXIST;
}

int
trunc_tb(tb_name_t tb_name,struct TB_MANAGER_ST * volatile tms){
     while(tms!=NULL){
        if(strcmp(tb_name,tms->tb_name)==0){
             tms->tb_cur_size=0;
             if(ftruncate(tms->tb_fd,0)!=0)
                 return -1;
            lseek(tms->tb_fd,0,SEEK_SET);
            return  free_tms(tms,0);
        }
        tms=tms->tb_manager_next;
     }
     return TE_DTEXIST;
}

int         
create_tb(int cl_sockfd,int data_len,int init_cur_size,int set_id,int item_max,tb_name_t tb_name,struct TB_MANAGER_ST * volatile * tms_p){ 
   tb_manager_st * temp_tms;
   req_data_st rds;
   tb_item_st * temp_tb_item;
   int offset=0,big_eme=0,base_eme_len,tol_eme_len;
   static int flag=0;
   static char * tb_item_filename,*tb_item_record;

   if(flag==0){
       if((tb_item_filename=malloc(sizeof(tb_name_t)+45))==NULL)
           errExit("malloc for tb_item_filename failed!\n");
       if((tb_item_record=malloc(sizeof(tb_name_t)+45))==NULL)
           errExit("malloc for tb_item_record failed!\n");
       flag=1;
   }
   
   if(set_id==1)
      item_max--;
   if(data_len>item_max || data_len<1)
       return TE_LEN;
   
   if(mkdir(tb_name,S_IRUSR | S_IWUSR | S_IXUSR)!=0)
       errExit("create %s dir failed!\n",tb_name);
   printf("1\n");
   if((temp_tms=malloc(sizeof(tb_manager_st)))==NULL)
       return TE_MALLOC;
   printf("2\n");
   temp_tms->tb_max_size=init_cur_size;
   temp_tms->tb_cur_size=0;
   if(pthread_mutex_init(&temp_tms->mtx,NULL)!=0)         //remember pthread_mutex_destroy()
       errExit("init mutex error!\n");
   if(pthread_cond_init(&temp_tms->cod,NULL)!=0)
       errExit("init cond error!\n");
   strncpy(temp_tms->tb_name,tb_name,sizeof(tb_name_t));
   if((temp_tms->tb_addr=malloc(temp_tms->tb_max_size))==NULL){
       free(temp_tms);
       return TE_MALLOC;
   }
   printf("3\n");
   temp_tms->tb_line_lock=NULL;
   if(set_id==1){
       if((temp_tms->tb_item_list=malloc(sizeof(tb_item_st)))==NULL){
           free_tms(temp_tms,1);
           return TE_MALLOC;
       }
       temp_tms->tb_item_list->var_type=U_INT;
       strcpy(temp_tms->tb_item_list->tb_item_nm,"id");
       temp_tms->tb_item_list->relate_offset=0;
       temp_tms->tb_item_list->tb_item_next=NULL;
       offset+=sizeof(id_t);
   }else
       temp_tms->tb_item_list=NULL;
   for(;data_len>0;data_len--){
       if(recv(cl_sockfd,&rds,sizeof(req_data_st),MSG_WAITALL)!=sizeof(req_data_st)){
           free_tms(temp_tms,1);
           return TE_READ;  
       }

       temp_tb_item=temp_tms->tb_item_list;
       while(temp_tb_item!=NULL){
           if(strcmp(temp_tb_item->tb_item_nm,rds.col_nm)==0)
               return TE_CHNAME;
           temp_tb_item=temp_tb_item->tb_item_next;
       }

       if((temp_tb_item=malloc(sizeof(tb_item_st)))==NULL){
           free_tms(temp_tms,1);
           return TE_MALLOC;
       }
       
       req_ntoh(&rds,sizeof(req_data_st));
       temp_tb_item->var_type=rds.var_type;
       strncpy(temp_tb_item->tb_item_nm,rds.col_nm,sizeof(chr_25_t));
       switch(temp_tb_item->var_type){
               case CHAR_25:
                   base_eme_len=sizeof(char);
                   tol_eme_len=25*base_eme_len;
                   big_eme=big_eme<base_eme_len?base_eme_len:big_eme;
                   break;
               case CHAR_255:
                   base_eme_len=sizeof(char);
                   tol_eme_len=255*base_eme_len;
                   big_eme=big_eme<base_eme_len?base_eme_len:big_eme;
                   break;
               case SHT:
                   printf("SHRT\n");
                   base_eme_len=sizeof(short);
                   tol_eme_len=base_eme_len;
                   big_eme=big_eme<base_eme_len?base_eme_len:big_eme;
                   break;
               case U_INT:
                   base_eme_len=sizeof(unsigned int);
                   tol_eme_len=base_eme_len;
                   big_eme=big_eme<base_eme_len?base_eme_len:big_eme;
                   break;
               case INT:
                   base_eme_len=sizeof(int);
                   tol_eme_len=base_eme_len;
                   big_eme=big_eme<base_eme_len?base_eme_len:big_eme;
                   break;
               case LONG:
                   base_eme_len=sizeof(long);
                   tol_eme_len=base_eme_len;
                   big_eme=big_eme<base_eme_len?base_eme_len:big_eme;
                   break;
               default:
                   free_tms(temp_tms,1);
                   printf("unknown var_type");
                   return TE_TYPE;
       }  
       if(offset==0)
           temp_tb_item->relate_offset=0;
       else{
           while(offset % base_eme_len!=0)
               offset++;
           temp_tb_item->relate_offset=offset;
       }
       offset+=tol_eme_len;

       temp_tb_item->tb_item_next=temp_tms->tb_item_list;
       temp_tms->tb_item_list=temp_tb_item;
       
   }
   printf("4\n");
   while(offset % big_eme!=0){
       offset++;
   }
   printf("offset:%d\n",offset);     
   temp_tms->tb_line_size=offset;
   temp_tms->temp_item_p=malloc(temp_tms->tb_line_size);
   if(temp_tms->temp_item_p==NULL)
       errExit("malloc for temp_tms->temp_item_p failed[db_func.c]!\n");

   printf("tb_name：%s\n",tb_name);
   snprintf(tb_item_filename,sizeof(tb_name_t)+45,"%s/%s.OK",tb_name,tb_name);
   snprintf(tb_item_record,sizeof(tb_name_t)+45,"%s/%s.swap.OK",tb_name,tb_name);
   
   if((temp_tms->tb_fd=open(tb_item_filename,O_CREAT | O_TRUNC | O_RDWR,S_IRUSR | S_IWUSR))==-1){
       free_tms(temp_tms,1);
       return TE_CREFL;
   }
   
   if((temp_tms->tb_swap_fd=open(tb_item_record,O_CREAT | O_TRUNC | O_RDWR,S_IRUSR | S_IWUSR))==-1){
       free_tms(temp_tms,1);
       return TE_CREFL;
   }
   
   snprintf(tb_item_filename,sizeof(tb_name_t)+45,"%s/%s.item.OK",tb_name,tb_name);
   snprintf(tb_item_record,sizeof(tb_name_t)+45,"%s/%s.item.swap.OK",tb_name,tb_name);
   
   printf("5\n");
   if((temp_tms->tb_item_fd=open(tb_item_filename,O_CREAT | O_TRUNC | O_RDWR,S_IRUSR | S_IWUSR))==-1){
       free_tms(temp_tms,1);
       return TE_CREFL;          
   }
   
   if((temp_tms->tb_item_swap_fd=open(tb_item_record,O_CREAT | O_TRUNC | O_RDWR,S_IRUSR | S_IWUSR))==-1){
       free_tms(temp_tms,1);
       return TE_CREFL;          
   }
   
   printf("6\n");
   while(temp_tb_item!=NULL){
       snprintf(tb_item_record,sizeof(tb_name_t)+12,"%s:%d:%d\n",temp_tb_item->tb_item_nm,temp_tb_item->var_type,temp_tb_item->relate_offset);
       if(write(temp_tms->tb_item_fd,tb_item_record,strlen(tb_item_record))!=strlen(tb_item_record)){
           free_tms(temp_tms,1);
           return TE_WRTFL;
       }
       temp_tb_item=temp_tb_item->tb_item_next;
   }
   temp_tms->tb_item_swap_flag=0;
   if(set_id!=1){
       close(temp_tms->tb_item_fd);
       close(temp_tms->tb_item_swap_fd);
       temp_tms->tb_item_fd=-1;
   }
   
   printf("7\n");
   temp_tms->tb_manager_next=*tms_p;
   *tms_p=temp_tms;
   return 0;
}

static line_lock_st * 
create_lls(struct TB_MANAGER_ST * volatile tms){
   line_lock_st * lls;

   if((lls=malloc(sizeof(line_lock_st)))==NULL)
        errExit(" malloc  failed[create_lls]\n");
   if(pthread_mutex_init(&lls->mtx,NULL)!=0)
        errExit("add_item mutex init failed!\n");
   if(pthread_cond_init(&lls->cod,NULL)!=0)
        errExit("add_item cond init failed!\n");
   
   lls->read_cnt=0;
   write_lock(&lls->mtx,&lls->cod,&lls->read_cnt);
            
   pthread_mutex_lock(&tms->mtx);
            
   lls->tb_line_p=tms->tb_addr+tms->tb_cur_size;
   tms->tb_cur_size+=tms->tb_line_size;
   memset(lls->tb_line_p,0,tms->tb_line_size);      
   return lls;         
}

int
add_item(int cl_socket_fd,int data_len,int item_max,int mem_limit,tb_name_t tb_name,struct TB_MANAGER_ST * tms){
   line_lock_st * temp_lls,*lls;
   tb_item_st * tis;
   req_data_st rds;
   int reuse_flag=0;

   if(data_len>item_max || data_len<1)
       return TE_LEN;
   while(tms!=NULL){
       if(strcmp(tb_name,tms->tb_name)==0)
           break;
       tms=tms->tb_manager_next;
    }
   if(tms==NULL)
       return TE_DTEXIST;
  
   if(tms->tb_item_fd!=-1){
       tis=tms->tb_item_list;
       while(tis!=NULL){
             if(strcmp(tis->tb_item_nm,"id")==0)
                 break;
             tis=tis->tb_item_next;
        }
        if(tis==NULL)
             return TE_STLOST;
   }
   
   if(tms->tb_line_size+tms->tb_cur_size>tms->tb_max_size){
        if(realloc_tb(tms,mem_limit)!=0){
            if((lls=reuse_deleted_item(tms->tb_line_lock))==NULL){
                return IE_MEMLIM;        
            }else{
                 memset(lls->tb_line_p,0,tms->tb_line_size);    
                 pthread_mutex_lock(&tms->mtx);
                 reuse_flag=1;
            }
        }else{
            lls=create_lls(tms);
        }
   }else{
        lls=create_lls(tms);
   }
   if(tms->tb_item_fd!=-1){
       *(id_t *)(lls->tb_line_p)=tis->relate_offset;
       tis->relate_offset+=1;
   }
   pthread_mutex_unlock(&tms->mtx);    
   
   lls->isDeleted=FALSE;
   lls->line_lock_next=NULL;

   for(;data_len>0;data_len--){
      if(recv(cl_socket_fd,&rds,sizeof(req_data_st),MSG_WAITALL)!=sizeof(req_data_st)){
          pthread_mutex_destroy(&lls->mtx);
          pthread_cond_destroy(&lls->cod);
          free(lls);
          return TE_READ;  
      }
      req_ntoh(&rds,sizeof(req_data_st));
      tis=tms->tb_item_list;
      while(tis!=NULL){
         if(strcmp(tis->tb_item_nm,rds.col_nm)==0 && strcmp(rds.col_nm,"id")!=0)
             break;
         tis=tis->tb_item_next;
      }
      if(tis==NULL)
             return IE_DTEXIST;
      switch(tis->var_type){
          case CHAR_25:
              strncpy((char *)(lls->tb_line_p)+tis->relate_offset,rds.row_vl,sizeof(chr_25_t));
              ((char *)lls->tb_line_p)[tis->relate_offset+sizeof(chr_25_t)-1]='\0';
              break;
          case CHAR_255:
              strncpy((char *)(lls->tb_line_p)+tis->relate_offset,rds.row_vl,sizeof(chr_255_t));
              ((char *)lls->tb_line_p)[tis->relate_offset+sizeof(chr_255_t)-1]='\0';
              break;
          case SHT:
              *((short *)(&lls->tb_line_p+tis->relate_offset))=ntohs(*(short *)rds.row_vl);
              break;
          case U_INT:
              *((unsigned int *)(&lls->tb_line_p+tis->relate_offset))=ntohl(*(unsigned int *)rds.row_vl);
              break;
          case INT:
              *((int *)(&lls->tb_line_p+tis->relate_offset))=ntohl(*(int *)rds.row_vl);
              break;
          case LONG:
              *((long *)(&lls->tb_line_p+tis->relate_offset))=ntohl_(*(long *)rds.row_vl);
              break;
      }
   }

   if(reuse_flag){
       write_unlock(&lls->mtx);
       return 0;
   }

   if(tms->tb_line_lock==NULL){
       pthread_mutex_lock(&tms->mtx);
       if(tms->tb_line_lock==NULL){
            tms->tb_line_lock=lls;
            write_unlock(&lls->mtx);
            pthread_mutex_unlock(&tms->mtx);
            return 0;
       }
       pthread_mutex_unlock(&tms->mtx);

   }
   temp_lls=tms->tb_line_lock;
   while(TRUE){
      if(temp_lls->line_lock_next==NULL){
           write_lock(&temp_lls->mtx,&temp_lls->cod,&temp_lls->read_cnt);
           if(temp_lls->line_lock_next==NULL){
               temp_lls->line_lock_next=lls;
               write_unlock(&temp_lls->mtx);
               write_unlock(&lls->mtx);
               break;
           }
           write_unlock(&temp_lls->mtx);
     }
     temp_lls=temp_lls->line_lock_next;
  }
   return 0;
}

static int
match_item(line_lock_st * lls ,tb_item_st * tis,req_data_st * rds_p){
   int offset;
   short temp_sht,temp_sht_r;
   int temp_int,temp_int_r;
   unsigned int temp_u_int,temp_u_int_r;
   long temp_long,temp_long_r;

   offset=tis->relate_offset;
   switch(tis->var_type){
       case CHAR_25:
           rds_p->row_vl[sizeof(chr_25_t)-1]='\0';
           ((char *)(lls->tb_line_p+offset))[sizeof(chr_25_t)-1]='\0';
           switch(rds_p->lo_type){
               case GE:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))>=0;
                   break;
               case LE:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))<=0;
                   break;
               case NE:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))!=0;
                   break;
               case EQ:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))==0;
                   break;
               case GT:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))>0;
                   break;
               case LT:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))<0;
                   break;
               case ALL:
                   return 1;
                   break;
           }
           break;
       case CHAR_255:
           rds_p->row_vl[sizeof(chr_255_t)-1]='\0';
           ((char *)(lls->tb_line_p+offset))[sizeof(chr_255_t)-1]='\0';
           switch(rds_p->lo_type){
               case GE:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))>=0;
                   break;
               case LE:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))<=0;
                   break;
               case NE:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))!=0;
                   break;
               case EQ:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))==0;
                   break;
               case GT:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))>0;
                   break;
               case LT:
                   return strcmp(rds_p->row_vl,(char *)(lls->tb_line_p+offset))<0;
                   break;
               case ALL:
                   return 1;
                   break;
           }
           break;
       case SHT:
           temp_sht=ntohs(*(short *)(rds_p->row_vl));
           temp_sht_r=ntohs(*(short *)(lls->tb_line_p+offset));
           switch(rds_p->lo_type){
               case GE:
                   return temp_sht>=temp_sht_r?1:0;
                   break;
               case LE:
                   return temp_sht<=temp_sht_r?1:0;
                   break;
               case NE:
                   return temp_sht!=temp_sht_r?1:0;
                   break;
               case EQ:
                   return temp_sht==temp_sht_r?1:0;
                   break;
               case GT:
                   return temp_sht>temp_sht_r?1:0;
                   break;
               case LT:
                   return temp_sht<temp_sht_r?1:0;
                   break;
               case ALL:
                   return 1;
                   break;
           }
           break;
       case U_INT:
           if(strcmp(tis->tb_item_nm,"id")==0)
               offset=0;
           temp_u_int=ntohl(*(unsigned int *)(rds_p->row_vl));
           temp_u_int_r=ntohs(*(unsigned int *)(lls->tb_line_p+offset));
           switch(rds_p->lo_type){
               case GE:
                   return temp_u_int>=temp_u_int_r?1:0;
                   break;
               case LE:
                   return temp_u_int<=temp_u_int_r?1:0;
                   break;
               case NE:
                   return temp_u_int!=temp_u_int_r?1:0;
                   break;
               case EQ:
                   return temp_u_int==temp_u_int_r?1:0;
                   break;
               case GT:
                   return temp_u_int>temp_u_int_r?1:0;
                   break;
               case LT:
                   return temp_u_int<temp_u_int_r?1:0;
                   break;
               case ALL:
                   return 1;
                   break;
           }
           break;
       case INT:
           temp_int=ntohl(*( int *)(rds_p->row_vl));
           temp_int_r=ntohs(*(int *)(lls->tb_line_p+offset));
           switch(rds_p->lo_type){
               case GE:
                   return temp_int>=temp_int_r?1:0;
                   break;
               case LE:
                   return temp_int<=temp_int_r?1:0;
                   break;
               case NE:
                   return temp_int!=temp_int_r?1:0;
                   break;
               case EQ:
                   return temp_int==temp_int_r?1:0;
                   break;
               case GT:
                   return temp_int>temp_int_r?1:0;
                   break;
               case LT:
                   return temp_int<temp_int_r?1:0;
                   break;
               case ALL:
                   return 1;
                   break;
           }
           break;
       case LONG:
           temp_long=ntohl_(*( long *)(rds_p->row_vl));
           temp_long_r=ntohs(*(long *)(lls->tb_line_p+offset));
           switch(rds_p->lo_type){
               case GE:
                   return temp_long>=temp_long_r?1:0;
                   break;
               case LE:
                   return temp_long<=temp_long_r?1:0;
                   break;
               case NE:
                   return temp_long!=temp_long_r?1:0;
                   break;
               case EQ:
                   return temp_long==temp_long_r?1:0;
                   break;
               case GT:
                   return temp_long>temp_long_r?1:0;
                   break;
               case LT:
                   return temp_long<temp_long_r?1:0;
                   break;
               case ALL:
                   return 1;
                   break;
           }
   }
   return 0;
}

static int
match_set(line_lock_st * lls ,tb_item_st * tis ,req_data_st * rds_p,long ** lls_search_set_p,int lssp_len){
    int rt_result,matched_item_len=0,i,j;

    if(lssp_len==0){
       while(lls!=NULL){
           read_lock(&lls->mtx,&lls->read_cnt);

           if(lls->isDeleted==TRUE){
               read_unlock(&lls->mtx,&lls->cod,&lls->read_cnt);
               lls=lls->line_lock_next;
               continue;     
           }
           rt_result=match_item(lls,tis,rds_p);

           read_unlock(&lls->mtx,&lls->cod,&lls->read_cnt);
           
           if(rt_result!=0){
               printf("matched!\n");
               printf("lls-long:%ld,lls-p:%p\n",(long)lls,lls);
               (*lls_search_set_p)[ matched_item_len++]=(long)lls;     
           }
           lls=lls->line_lock_next;
      }
    }else{
       for(i=0;i<lssp_len;i++){
           lls=(line_lock_st *)*(*lls_search_set_p+i);

           read_lock(&lls->mtx,&lls->read_cnt);

           if(lls->isDeleted==TRUE){
               read_unlock(&lls->mtx,&lls->cod,&lls->read_cnt);
               lls=lls->line_lock_next;
               continue;     
           }
           rt_result=match_item(lls,tis,rds_p);

           read_unlock(&lls->mtx,&lls->cod,&lls->read_cnt);
           
           lls=lls->line_lock_next;
           if(rt_result==0){
               lls_search_set_p[i]=0;     
           }
       }
       matched_item_len=j=0;
       for(;j<lssp_len;i++){
           if(lls_search_set_p[j]!=0){
               if(matched_item_len!=j)
                    lls_search_set_p[matched_item_len]=lls_search_set_p[j];
               matched_item_len++;
               j++;
           }
           else{
               j++;     
           }
       }
    }
    return matched_item_len;
}

static int
check_realloc_lssl(struct TB_MANAGER_ST * volatile tms){
   void * temp_ptr;
   
   if(lls_search_set_len*tms->tb_line_size < tms->tb_max_size/tms->tb_line_size){
       if((temp_ptr=realloc(lls_search_set,sizeof(long)*(tms->tb_max_size/tms->tb_line_size)))==NULL)     
            return TE_MALLOC;
       else{
            lls_search_set=temp_ptr;
            lls_search_set_len=tms->tb_max_size/tms->tb_line_size;
       }
   }
   return 0;
}

int 
delete_item(int socket_fd,int data_len,int dt_max,tb_name_t tb_name,struct TB_MANAGER_ST * volatile tms){
   tb_item_st * tis;
   line_lock_st * lls;
   req_data_st rds;
   int rt_set_len=0,i;

   if(data_len>dt_max || data_len <1)
       return TE_LEN;
   while(tms!=NULL){
       if(strcmp(tb_name,tms->tb_name)==0)
           break;
       tms=tms->tb_manager_next;
    }
   if(tms==NULL)
       return TE_DTEXIST;
    
   if(check_realloc_lssl(tms)!=0)
      return TE_MALLOC;
   
   for(;data_len>0;data_len--){
      printf("test del_item!\n");
      if(recv(socket_fd,&rds,sizeof(req_data_st),MSG_WAITALL)!=sizeof(req_data_st))
          return TE_READ;
      req_ntoh(&rds,sizeof(req_data_st));
      tis=tms->tb_item_list;
      while(tis!=NULL){
         if(strcmp(tis->tb_item_nm,rds.col_nm)==0)
             break;
         tis=tis->tb_item_next;
      }
      if(tis==NULL)
             return IE_DTEXIST;

   rt_set_len=match_set(rt_set_len==0?tms->tb_line_lock:NULL,tis,&rds,&lls_search_set,rt_set_len);
   if(rt_set_len==0)
       return IE_NONE;
   }
    printf("rt_set_len:%d\n",rt_set_len); 
    printf("test del_item!\n");
   for(i=0;i<rt_set_len;i++){
       printf("lls_search_set:%ld\n",lls_search_set[i]);
       lls=(line_lock_st *)(lls_search_set[i]);
       printf("del_item write_lock before\n");
       write_lock(&lls->mtx,&lls->cod,&lls->read_cnt);
       printf("del_item write_lock after\n");
       
       lls->isDeleted=TRUE;

       write_unlock(&lls->mtx);
   }
   return 0;
}

int
query_item(int socket_fd,int data_out_fd,int data_len,int dt_max,int rt_text_flag,tb_name_t tb_name,struct TB_MANAGER_ST * volatile tms ){
   tb_item_st * tis;
   line_lock_st * lls;
   req_data_st rds;
   int rt_set_len=0,i;

   if(data_len>dt_max || data_len <1)
       return TE_LEN;
   while(tms!=NULL){
       if(strcmp(tb_name,tms->tb_name)==0)
           break;
       tms=tms->tb_manager_next;
    }
   if(tms==NULL)
       return TE_DTEXIST;
   
   if(check_realloc_lssl(tms)!=0)
      return TE_MALLOC;

   for(;data_len>0;data_len--){
      if(recv(socket_fd,&rds,sizeof(req_data_st),MSG_WAITALL)!=sizeof(req_data_st))
          return TE_READ;
      req_ntoh(&rds,sizeof(req_data_st));
      tis=tms->tb_item_list;
      while(tis!=NULL){
         if(strcmp(tis->tb_item_nm,rds.col_nm)==0)
             break;
         tis=tis->tb_item_next;
      }
      if(tis==NULL)
             return IE_DTEXIST;

   rt_set_len=match_set(rt_set_len==0?tms->tb_line_lock:NULL,tis,&rds,&lls_search_set,rt_set_len);
   if(rt_set_len==0)
       return IE_NONE;
   }
   
   if(ftruncate(data_out_fd,0)!=0)
       return IE_TRUNCFL;
   lseek(data_out_fd,0,SEEK_SET);
   for(i=0;i<rt_set_len;i++){
       lls=(line_lock_st *)(lls_search_set[i]);

       read_lock(&lls->mtx,&lls->read_cnt);
       
        if(!rt_text_flag){
           tis=tms->tb_item_list;
           while(tis!=NULL){
              pthread_mutex_lock(&tms->mtx);
              memcpy(tms->temp_item_p,lls->tb_line_p,tms->tb_line_size);
              switch(tis->var_type){
                  case SHT:
                      *(short *)(tms->temp_item_p+tis->relate_offset)=htons(*(short *)(lls->tb_line_p+tis->relate_offset));
                      break;
                  case U_INT:
                      *(unsigned int *)(tms->temp_item_p+tis->relate_offset)=htonl(*(unsigned int *)(lls->tb_line_p+tis->relate_offset));
                      break;
                  case INT:
                      *(int *)(tms->temp_item_p+tis->relate_offset)=htonl(*(int *)(lls->tb_line_p+tis->relate_offset));
                      break;
                  case LONG:
                      *(long *)(tms->temp_item_p+tis->relate_offset)=htonl_(*(long *)(lls->tb_line_p+tis->relate_offset));
                      
              }
              if(write(data_out_fd,tms->temp_item_p,tms->tb_line_size)!=tms->tb_line_size){
                    pthread_mutex_unlock(&tms->mtx);
                    read_unlock(&lls->mtx,&lls->cod,&lls->read_cnt);
                    return IE_WRTFL; 
              }

              pthread_mutex_unlock(&tms->mtx);
              tis=tis->tb_item_next;
              data_len++;
           }
        }

       read_unlock(&lls->mtx,&lls->cod,&lls->read_cnt);
   }
   return -data_len;  
}

int
modify_item(int socket_fd,int data_len,int mod_data_len,int dt_max,tb_name_t tb_name,struct TB_MANAGER_ST * volatile tms ){
   tb_item_st * tis;
   line_lock_st * lls;
   req_data_st rds;
   int rt_set_len=0,i;
   req_mod_st * temp_rms;

   if(data_len>dt_max || data_len <1 || mod_data_len>dt_max || mod_data_len<0)
       return TE_LEN;
   
  printf("check_realloc after\n"); 
   if(rms_list_flag==0){
       for(i=0;i<mod_data_len;i++){
          if((temp_rms=malloc(sizeof(req_mod_st)))==NULL)
              return TE_MALLOC;
          temp_rms->next=rms_list;
          rms_list=temp_rms;
       } 
       rms_list_flag=1;
   }

   while(tms!=NULL){
       if(strcmp(tb_name,tms->tb_name)==0)
           break;
       tms=tms->tb_manager_next;
    }
   if(tms==NULL)
       return TE_DTEXIST;
   
   if(check_realloc_lssl(tms)!=0)
      return TE_MALLOC;
   
   printf("none NULL!\n");
   for(;data_len>0;data_len--){
      if(recv(socket_fd,&rds,sizeof(req_data_st),MSG_WAITALL)!=sizeof(req_data_st))
          return TE_READ;
      req_ntoh(&rds,sizeof(req_data_st));
      tis=tms->tb_item_list;
      while(tis!=NULL){
         if(strcmp(tis->tb_item_nm,rds.col_nm)==0)
             break;
         tis=tis->tb_item_next;
      }
      if(tis==NULL)
             return IE_DTEXIST;

   rt_set_len=match_set(rt_set_len==0?tms->tb_line_lock:NULL,tis,&rds,&lls_search_set,rt_set_len);
   if(rt_set_len==0)
       return IE_NONE;
   }
   temp_rms=rms_list;
   for(i=0;i<mod_data_len;i--){
       printf("what?\n");
      if(recv(socket_fd,temp_rms,sizeof(req_mod_st),MSG_WAITALL)!=sizeof(req_mod_st))
          return TE_READ;
      temp_rms->col_nm[sizeof(chr_25_t)-1]='\0';
      temp_rms->row_vl[sizeof(chr_255_t)-1]='\0';
      temp_rms=temp_rms->next;
   }

   for(i=0;i<rt_set_len;i++){
       lls=(line_lock_st *)(lls_search_set[i]);
       
       temp_rms=rms_list;
       for(data_len=0;data_len<mod_data_len;data_len++){
          tis=tms->tb_item_list;
          while(tis!=NULL){
             if(strcmp((tis->tb_item_nm),temp_rms->col_nm)==0 && strcmp(tis->tb_item_nm,"id")!=0)
                  break;
             tis=tis->tb_item_next;
          }
          if(tis==NULL)
              return IE_DTEXIST;
        
          write_lock(&lls->mtx,&lls->cod,&lls->read_cnt);
          
          switch(tis->var_type){
              case CHAR_25:case CHAR_255:
                  strcpy((char *)(lls->tb_line_p+tis->relate_offset),temp_rms->row_vl); 
                  break;
              case SHT:
                  *(short *)(lls->tb_line_p+tis->relate_offset)=ntohs(*(short *)temp_rms->row_vl);
                  break;
              case U_INT:
                  *(unsigned int *)(lls->tb_line_p+tis->relate_offset)=ntohl(*(unsigned int *)temp_rms->row_vl);
                  break;
              case INT:
                  *(int *)(lls->tb_line_p+tis->relate_offset)=ntohl(*(int *)temp_rms->row_vl);
                  break;
              case LONG:
                  *(long *)(lls->tb_line_p+tis->relate_offset)=ntohl_(*(long *)temp_rms->row_vl);
          }
      
          write_unlock(&lls->mtx);
          
          temp_rms=temp_rms->next;
       }
   }
   return 0;
}



