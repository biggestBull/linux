#define _BSD_SOURCE
#define _POSIX_C_SOURCE 199309
#include<time.h>
#include"./db_manager.h"
#include<unistd.h>
#include<fcntl.h>
#include<sys/stat.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<netdb.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<signal.h>

#define BACKLOG 3
#define ADDRSTRLEN (NI_MAXHOST+NI_MAXSERV+10)

#define CONF_LINE_SIZE 60  
#define DB_PREX "db_"
#define PORT_LEN 6  

extern int init_db_conf();
extern int create_db_list();
extern void bind_socket();
extern int accept_con();
extern int handle_con(const char *,int );
extern void timer_handler(union sigval);

static char rdl_buf[CONF_LINE_SIZE];
int thr_max=0, tb_max_num=0;
int port=0, pro_max=0,db_max_num=0,sv_socket_fd,cur_pro_num=0,cur_db_num=0,int_timer=0;
db_manager_st *  dms;
static int db_nm_fd,db_nm_swap_fd,db_nm_swap_flag;
struct msghdr ipc_msg;

void
timer_handler(union sigval sival){
   db_manager_st * dms_p;
   fs_pipe_ipc_st ipc_data;
   int db_rname_l,db_prex_l,cur_record_fd;

   ipc_data.event_type=FS_TEST;
   dms_p=dms;
   db_prex_l=strlen(DB_PREX);

   cur_record_fd=db_nm_swap_flag?db_nm_swap_fd:db_nm_fd;
   printf("tfd:%d,dfd:%d,sfd:%d\n",cur_record_fd,db_nm_fd,db_nm_swap_fd);
   if(!db_nm_swap_flag)
       if(rename("db.record.swap.OK","db.record.swap")==-1)
           errExit("to db.record.swap failed [timer_handler]\n");
   else
       if(rename("db.record.OK","db.record")==-1)
           errExit("to db.record failed [timer_handler]\n");
    
   if(ftruncate(cur_record_fd,0)!=0)
       errExit("truncate 0 failed!\n");
   lseek(cur_record_fd,SEEK_SET,0);
   
   printf("[check dms]:\n");
   while(dms_p!=NULL){
       printf("\tdb:%s:",dms_p->db_name);
       snprintf(rdl_buf,CONF_LINE_SIZE,"%s:%s\n",dms_p->db_name+db_prex_l,dms_p->passwd);
       if(write(cur_record_fd,rdl_buf,strlen(rdl_buf))!=strlen(rdl_buf))
           errExit("write to db.record failed1\n");

       if(dms_p->isOpenned==TRUE)
         // if(write(dms_p->unix_sock_fd[1],&ipc_data,sizeof(fs_pipe_ipc_st))==-1 && errno==EPIPE){
          if(sendmsg_(dms_p->unix_sock_fd[1],&ipc_data,&ipc_msg)!=0){
             dms_p->isOpenned=FALSE;
             close(dms_p->unix_sock_fd[1]);
             cur_pro_num--;
             printf("closed\n");
          }else{
             printf("openned\n");    
          }
       else
             printf("closed\n");
       dms_p=dms_p->db_manager_next;
   }
   if(!db_nm_swap_flag)
       if(rename("db.record.swap","db.record.swap.OK")==-1)
           errExit("to db.record.swap.OK failed [timer_handler]\n");
   else
       if(rename("db.record","db.record.OK")==-1)
           errExit("to db.record.OK failed [timer_handler]\n");
  db_nm_swap_flag=db_nm_swap_flag?0:1; 
}

int
main(int argc,char * argv[]){
   if(init_db_conf()!=0)
      errExit("init_db_conf\n");
   if(create_db_list()<0)
       errExit("create_db_list\n"); 
    bind_socket();
    printf("Waiting for connection,port:%d\n",port);
    if(signal(SIGPIPE,SIG_IGN)==SIG_ERR)
        errExit("SIG_ERR SIGPIPE!\n");
    if(signal(SIGCHLD,SIG_IGN)==SIG_ERR)
        errExit("SIG_ERR SIGCHLD\n");
    if(create_timer(int_timer,timer_handler)==-1)
        errExit("create_timer\n");
     accept_con();

}

int 
init_db_conf(){
   printf("read db.config……\n");
   int db_conf_fd,rd_result;
   int db_conf_value;
   char *p;

   db_conf_fd=open("./db.conf",O_RDONLY);
   if(db_conf_fd==-1){
      errExit("open db.conf\n");      
   }
   while((rd_result=readline(db_conf_fd,rdl_buf,(CONF_LINE_SIZE-1)))==0){
       p=rdl_buf;
       while(*p!='\0'){
           if(*p==':'){
               *p='\0';
               p++;
               break;
           }
           p++;
        }
       if(*p=='\0')
          continue;
       db_conf_value=atoi(p);
       if(db_conf_value<=0)
           errExit("atoi(%s)\n",db_conf_value);
       if(strcmp(rdl_buf,"port")==0){
           port=db_conf_value;
       }else if(strcmp(rdl_buf,"thr_max")==0){
           thr_max=db_conf_value;     
       }else if(strcmp(rdl_buf,"pro_max")==0){
           pro_max=db_conf_value;     
       }else if(strcmp(rdl_buf,"db_max_num")==0){
           db_max_num=db_conf_value;     
       }else if(strcmp(rdl_buf,"tb_max_num")==0){
           tb_max_num=db_conf_value;     
       }else if(strcmp(rdl_buf,"int_timer")==0){
           int_timer=db_conf_value;
       }
       db_conf_value=0;
   }
   if(rd_result==-1)
       return -1;
   if(close(db_conf_fd)==-1)
       errExit("close fd\n");
   if(port!=0 && pro_max!=0 && thr_max!=0 && db_max_num!=0 && tb_max_num!=0)
       return 0;
   return 1;
}

int
create_db_list(){
   printf("read db.record......\n");
   int rd_result;
   db_manager_st * temp_dms;
   int temp_fd;
   char * p;

   db_nm_swap_flag=0;
   if(access("db.record.OK",0)==0 && access("db.record.swap.OK",0)!=0){
       if(rename("db.record.swap","db.record.swap.OK")==-1)
           errExit("to db.record.swap.OK rename failed\n");
   }else if(access("db.record.OK",0)!=0 && access("db.record.swap.OK",0)==0){
       if(rename("db.record","db.record.OK")==-1)
           errExit("to db.record.OK rename failed\n");
       db_nm_swap_flag=1;
   }
               
   db_nm_fd=open("./db.record.OK",O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
   if(db_nm_fd==-1)
       errExit("db_record_fd error!\n");
   db_nm_swap_fd=open("./db.record.swap.OK",O_CREAT | O_RDWR,S_IRUSR | S_IWUSR);
   if(db_nm_swap_fd==-1)
       errExit("db_record_swap_fd error!\n");
    
   temp_fd=db_nm_swap_flag?db_nm_swap_fd:db_nm_fd;
   printf("tfd:%d,dfd:%d,sfd:%d\n",temp_fd,db_nm_fd,db_nm_swap_fd);

   dms=NULL;
   while((rd_result=readline(temp_fd,rdl_buf,(sizeof(db_name_t)-strlen(DB_PREX)-1)))==0){
       if(rdl_buf[0]=='\0')
           continue;
       if(++cur_db_num>db_max_num){
         printf("Warning:db_max_num over the limit!\n");
         break;
       }
    
       p=rdl_buf;
       while(*p!='\0'){
           if(*p==':')
               break;
           p++;
       }
       if(*p=='\0')
           errExit("parse db.record line error!\n");
       *p++='\0';

       temp_dms=malloc(sizeof(db_manager_st));
       snprintf(temp_dms->db_name,sizeof(db_name_t),"%s%s",DB_PREX,rdl_buf);
       strcpy(temp_dms->passwd,p);
       temp_dms->isOpenned=FALSE;
       temp_dms->isDeleted=FALSE;
       
       temp_dms->db_manager_next=dms;
       dms=temp_dms;
   }
   if(rd_result==-1)
       errExit("readline db.record  -1\n");
   if(dms==NULL)
       return 1;
   return 0;
}

void
bind_socket(){
   int optval;
   struct addrinfo *result,*rp,hints;
   char  port_chr[PORT_LEN];
  
   memset(&hints,0,sizeof(hints));
   hints.ai_canonname=NULL;
   hints.ai_addr=NULL;
   hints.ai_next=NULL;
   hints.ai_socktype=SOCK_STREAM;
   hints.ai_family=AF_INET;
   hints.ai_flags=AI_PASSIVE | AI_NUMERICSERV;

   snprintf(port_chr,PORT_LEN,"%d",port);
   if(getaddrinfo(NULL,port_chr,&hints,&result)!=0)
       errExit("getaddrinfo……\n");
   optval=1;
   for(rp=result;rp!=NULL;rp=rp->ai_next){
       sv_socket_fd=socket(rp->ai_family,rp->ai_socktype,rp->ai_protocol);
       if(setsockopt(sv_socket_fd,SOL_SOCKET,SO_REUSEADDR,&optval,sizeof(optval))==-1)
           errExit("setsockopt error\n");
       if(bind(sv_socket_fd,rp->ai_addr,rp->ai_addrlen)==0)
           break;
       close(sv_socket_fd);
   }
   if(rp==NULL)
       errExit("rp==NULL\n");
   if(listen(sv_socket_fd,BACKLOG)==-1)
       errExit("listen error\n");
   freeaddrinfo(result);

   }
   

int
accept_con(){
   struct sockaddr_storage claddr;
   socklen_t addrlen=sizeof(claddr);
   int cl_socket_fd;
   int cur_con_db_num=0;
   char host[NI_MAXHOST];
   char service[NI_MAXSERV];
   char addrStr[ADDRSTRLEN];
   for(;;){
      cl_socket_fd=accept(sv_socket_fd,(struct sockaddr *)&claddr,&addrlen);     //should client transfer zi ji xu?
      if(cl_socket_fd==-1)
          continue;
      if(getnameinfo((struct sockaddr *)&claddr,addrlen,host,NI_MAXHOST,service,NI_MAXSERV,0)==0)
          snprintf(addrStr,ADDRSTRLEN,"(%s:%s)",host,service);
      else
          snprintf(addrStr,ADDRSTRLEN,"(?UNKNOWN?)");
      printf("connection from:[socket_id:%d,%s]:\n",cl_socket_fd,addrStr);
      handle_con(addrStr,cl_socket_fd);
      close(cl_socket_fd);
   }
}

int 
handle_con(const char * addrStr,int cl_socket_fd){
   req_head cl_request;
   rep_head cl_response;
   int numread=0;
   int opt_result;
   int prex_len;
   db_manager_st * temp_dms_p,temp_dms;
   fs_pipe_ipc_st fs_ipc_data;

   if((numread=read(cl_socket_fd,&cl_request,sizeof(cl_request)))<0 || sizeof(cl_request)!=numread){
       printf("the request form %s faild!\n",addrStr);
       rep_err(cl_socket_fd,"request parments error!\n",&cl_response);
       return -1;
   }
   
   req_ntoh(&cl_request,sizeof(req_head));
   cl_request.op_type=cl_request.op_type;
   cl_request.db_name[sizeof(db_name_t)-1]='\0';
   cl_request.tb_name[sizeof(tb_name_t)-1]='\0';
   switch(cl_request.op_type){
       case CRE_DB:
           printf("CREATE DB ` %s ` from [%s]:",cl_request.db_name,addrStr);
           if(cur_db_num>=db_max_num){
                 printf("FAILED[reaches the limit]\n");
                 rep_err(cl_socket_fd,"The quatily of the db reaches the limit !\n",&cl_response);
                 return -1;
           }
           if((opt_result=db_create(cl_request.db_name,cl_request.tb_name,&dms))==1){
                 printf("FAILED[db has existed]\n");
                 rep_err(cl_socket_fd,"The db  has existed !\n",&cl_response);
                 return -1;
           }else if(opt_result==-1){
                 printf("FAILED[unknow error]\n");
                 rep_err(cl_socket_fd,"something wrong occured!\n",&cl_response);
                 return -1;
           }else{
                 printf("SUCCESS\n");
                 rep_suc(cl_socket_fd,&cl_response,0);
                 cur_db_num++;
                 return 0;
           }
           break;
       case DEL_DB:
           printf("DELETE DB ` %s ` from [%s]:",cl_request.db_name,addrStr);
           if((opt_result=db_delete(cl_request.db_name,cl_request.tb_name,&dms))==1){
                 printf("FAILED[dont exist]\n");
                 rep_err(cl_socket_fd,"The db  dont existed !\n",&cl_response);
                 return -1;
           }else if(opt_result==-1){
                 printf("FAILED[unknow error]\n");
                 rep_err(cl_socket_fd,"something wrong occured!\n",&cl_response);
                 return -1;
           }else if(opt_result==-2){
                 printf("FAILED[passwd incorrectly]\n");
                 rep_err(cl_socket_fd,"passwd incorrectly!\n",&cl_response);
                 return -1;
                    
           }else{
                 printf("SUCCESS\n");
                 rep_suc(cl_socket_fd,&cl_response,0);
                 cur_db_num--;
                 return 0;
           }
           break;
       case OPE_DB:
           printf("OPEN DB ` %s ` from [%s]:",cl_request.db_name,addrStr);
           temp_dms_p=dms;
           prex_len=strlen(DB_PREX);
           while(temp_dms_p!=NULL){
               if(strcmp(temp_dms_p->db_name+prex_len,cl_request.db_name)==0 )
                   break;
               temp_dms_p=temp_dms_p->db_manager_next;
           }
           if(temp_dms_p==NULL){
               printf("FAILED[db dont exist]\n");
               rep_err(cl_socket_fd,"db dont exist!\n",&cl_response);
               return -1;
           }
           
           if(check_passwd(temp_dms_p->passwd,cl_request.tb_name)==0){
                 printf("FAILED[passwd incorrectly]\n");
                 rep_err(cl_socket_fd,"passwd incorrectly!\n",&cl_response);
                 return -1;
           }

           fs_ipc_data.event_type=FS_CONN;
           fs_ipc_data.cl_socket=cl_socket_fd;

           if(temp_dms_p->isOpenned==TRUE){
               if(sendmsg_(temp_dms_p->unix_sock_fd[1],&fs_ipc_data,&ipc_msg)!=0){
                    temp_dms_p->isOpenned=FALSE;
                    close(temp_dms_p->unix_sock_fd[1]);
                    cur_pro_num--;
               }else{
                    printf("SUCCESS[OPEN]\n");
                    return 0;
               }
                
           }
           if(cur_pro_num>=pro_max){
                 printf("FAILED[reache the limit]\n");
                 rep_err(cl_socket_fd,"The quatily of the fork reaches the limit !\n",&cl_response);
                 return -1;
           }

           if(socketpair(AF_UNIX,SOCK_STREAM,0,temp_dms_p->unix_sock_fd)){
               printf("FAILED[socketpair failed]\n");
               rep_err(cl_socket_fd,"something wrong occured!\n",&cl_response);
               return -1;
           }

           temp_dms=*temp_dms_p;
           temp_dms.db_manager_next=NULL;
           
           fflush(stdout);
           switch(fork()){
               case -1:
                   printf("FAILED[fork failed]\n");
                   temp_dms_p->isOpenned=FALSE;
                   printf("on fork() error \n");
                   break;
               case 0:
                   if(close(temp_dms_p->unix_sock_fd[1])==-1)
                       errExit("on close unix_sock_fd\n");
                   tb_handler(temp_dms);
                   _exit(0);
               default:
                   if(close(temp_dms_p->unix_sock_fd[0])==-1){
                       printf("FAILED[close unix_sock_fd[0] failed]\n");
                       printf("close fd[0] error!\n");
                       close(temp_dms_p->unix_sock_fd[1]);
                       return -1;
                     }
                   if(sendmsg_(temp_dms_p->unix_sock_fd[1],&fs_ipc_data,&ipc_msg)!=0){
                       close(temp_dms_p->unix_sock_fd[1]);
                       return -1;
                     }
                   printf("SUCCESS[CREATE]\n");
                   temp_dms_p->isOpenned=TRUE;
                   cur_pro_num++;
                   return 0;
           }

           break;
       default:
           printf("op_type dont exist!\n");
           rep_err(cl_socket_fd,"op_type dont exist!\n",&cl_response);
           return -1;
   }
}














