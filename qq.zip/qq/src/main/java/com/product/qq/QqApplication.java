package com.product.qq;

import com.product.qq.init.Init;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@MapperScan("com.product.qq.dao")
@SpringBootApplication
public class QqApplication {
    public static void main(String[] args) {
        SpringApplication.run(QqApplication.class, args);
        Init.initGroupUser();
    }
}
