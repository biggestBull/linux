package com.product.qq.service;

import com.product.qq.dao.IMessageDao;
import com.product.qq.dto.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MessageService implements IMessageDao {
    @Autowired
    IMessageDao iMessageDao;

    @Override
    public List<Message> getGenPriMsg(Integer id) {
        return iMessageDao.getGenPriMsg(id);
    }

    @Override
    public List<Message> getGenGroMsg(List<Integer> gid) {
        return iMessageDao.getGenGroMsg(gid);
    }

    @Override
    public List<Message> getContMsg(Integer id) {
        return iMessageDao.getContMsg(id);
    }

    @Override
    public List<Message> getPriHistMsg(int id, int from, int index, int num) {
        return iMessageDao.getPriHistMsg(id,from,index,num);
    }

    @Override
    public List<Message> getGroHistMsg( Integer from, Integer index,Integer num) {
        return iMessageDao.getGroHistMsg(from,index,num);
    }

    @Override
    public Integer addMessage(Message message) {
        return iMessageDao.addMessage(message);
    }

    @Override
    public Message getMessageById(Integer id) {
        return iMessageDao.getMessageById(id);
    }

    @Override
    public Integer delMessage(Integer id) {
        return iMessageDao.delMessage(id);
    }

    @Override
    public List<Integer> checkMsgIsExist(int user_id, int send_to, int type) {
        return iMessageDao.checkMsgIsExist(user_id,send_to,type);
    }

    @Override
    public Integer updateMsgStatus(int user_id, int send_to,int type) {
        return iMessageDao.updateMsgStatus(user_id,send_to,type);
    }

    @Override
    public Integer incrementMsgPos(int id) {
        return iMessageDao.incrementMsgPos(id);
    }

    @Override
    public Integer incrementMsgNeg(int id) {
        return iMessageDao.incrementMsgNeg(id);
    }
}
