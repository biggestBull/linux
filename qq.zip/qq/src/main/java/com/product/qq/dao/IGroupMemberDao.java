package com.product.qq.dao;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface IGroupMemberDao {
    @Select("select count(1) from group_member where user_id=#{user_id} and group_id=#{group_id}")
    Integer checkMemeberIsExist( @Param("user_id")int user_id , @Param("group_id")int group_id);

    @Delete("delete from group_member where user_id=#{user_id} and group_id=#{group_id}")
    Integer delMemeber(@Param("user_id")int user_id , @Param("group_id")int group_id);

    @Delete("delete from group_member where group_id=#{group_id}")
    Integer delAllMember(@Param("group_id")int group_id);

    @Insert("insert into group_member(group_id,user_id)values(#{gid},#{uid})")
    Integer addMember(@Param("gid")int gid,@Param("uid")int uid);
}
