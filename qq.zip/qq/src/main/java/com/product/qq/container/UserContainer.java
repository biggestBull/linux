package com.product.qq.container;

import com.product.qq.dto.User;
import com.product.qq.service.UserService;
import java.util.Map;

public class UserContainer {

    private static UserContainer userContainer;
    public Map<Integer, User> users;
    private UserContainer(){}
    public static UserContainer getInstance(UserService userService){
        userContainer=new UserContainer();
        userContainer.users=userService.getAllUser();
        return userContainer;
    }
    public static UserContainer getInstance(){
        return userContainer;
    }
}
