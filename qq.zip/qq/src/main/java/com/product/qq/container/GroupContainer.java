package com.product.qq.container;

import com.product.qq.dto.Group;
import com.product.qq.service.GroupService;
import java.util.Map;

public class GroupContainer {
    private static GroupContainer groupContainer;
    public Map<Integer, Group> groups;
    private GroupContainer(){}
    public static GroupContainer getInstance(GroupService groupService){
        groupContainer=new GroupContainer();
        groupContainer.groups=groupService.getAllGroup();
        return groupContainer;
    }
    public static GroupContainer getInstance(){
        return groupContainer;
    }
}
