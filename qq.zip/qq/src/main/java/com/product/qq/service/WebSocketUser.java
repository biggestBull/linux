package com.product.qq.service;

import com.alibaba.fastjson.JSONObject;
import com.product.qq.container.UserContainer;
import com.product.qq.controller.ContGroupMsgContoller;
import com.product.qq.controller.ContUserMsgController;
import com.product.qq.dto.Group;
import com.product.qq.dto.Message;
import com.product.qq.dto.User;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

class WebSocketUser {
     static void notifyUG(User user, int flag){            //flag：上下线
        JSONObject jsonObject=new JSONObject();
        Message message;
        List<Message> messages=new ArrayList<>();
        User destu;
        Group destg;

        jsonObject.put("type",3);
        jsonObject.put("primsg",null);
        jsonObject.put("gromsg",null);
        message= ContUserMsgController.constructMsg(0,user.getName(),user.getId(),0,0,0,0);
        messages.add(message);
         for(Integer key:user.friends.keySet()){
            destu=user.friends.get(key);
            message.setSend_to(destu.getId());
            message.setType(flag==1?50:51);
            jsonObject.put("contmsg",messages);
            ContGroupMsgContoller.sendMsg(destu.session,jsonObject.toJSONString());
        }

        for(Integer gid : user.groups.keySet()){
            destg=user.groups.get(gid);
            for(Integer uid:destg.member.keySet()){
                destu=destg.member.get(uid);
                message.setSend_to(destu.getId());
                message.setType(flag==1?52:53);
                jsonObject.put("contmsg",messages);
                ContGroupMsgContoller.sendMsg(destu.session,jsonObject.toJSONString());
            }
        }
    }

    static void searchUser(String name,UserContainer userContainer,User user){
        List<User> users =new ArrayList<>();
        JSONObject jsonObject = new JSONObject();
        User friend;

        for(Integer key : userContainer.users.keySet()){
            friend=userContainer.users.get(key);
            if(friend==user)
                continue;
            if(friend.getName().equals(name) && (user.friends.get(key)==null || user.friends.get(key).getId()!=friend.getId())){
                users.add(userContainer.users.get(key));
            }
        }
        jsonObject.put("type",5);
        jsonObject.put("users",users);
        ContGroupMsgContoller.sendMsg(user.session,jsonObject.toJSONString());
    }

    static void addFriend(int send_to,UserContainer userContainer,User user,MessageService messageService) {
        List<Message> messages ;
        Message message;
        JSONObject jsonObject = new JSONObject();
        User destu;
        List<Integer> ids;

        destu = userContainer.users.get(send_to);
        System.out.println(user.getName()+" want "+destu.getName()+" friend ship");
        if (user.friends.get(send_to) == null && destu!=null) {
            int id;
            ids=messageService.checkMsgIsExist(user.getId(),send_to,3);
            System.out.println(ids.size());
            if(ids.size()==0) {
                message = ContUserMsgController.constructMsg(3, user.getName(), user.getId(), destu.getId(), 0, 0, 0);
                id = messageService.addMessage(message);
                System.out.println(destu.session);
                if (destu.session != null) {
                    message.setId(id);
                    jsonObject.put("type", 3);
                    messages=new ArrayList<>();
                    messages.add(message);
                    jsonObject.put("contmsg", messages);
                    jsonObject.put("primsg", null);
                    jsonObject.put("gromsg", null);
                    ContGroupMsgContoller.sendMsg(destu.session, jsonObject.toJSONString());
                }
            }
        }
    }

    static void agreeFriendship(int send_to, UserContainer userContainer,User user,MessageService messageService,FriendService friendService) {
        Message message ;
        List<Message> messages;
        JSONObject jsonObject = new JSONObject();
        User destu;
        List<User> userList=new ArrayList<>();

        destu = user.friends.get(send_to);
        if (destu == null && userContainer.users.get(send_to)!=null) {
            List<Integer> ids;
            int id;

            ids = messageService.checkMsgIsExist(send_to, user.getId(), 3);
            destu = userContainer.users.get(send_to);
            if (ids.size() >= 1) {
                for (int i : ids) {
                    messageService.delMessage(i);
                }
                friendService.addFriend(send_to, user.getId());
                friendService.addFriend(user.getId(), send_to);
                synchronized (userContainer) {
                    user.friends.put(destu.getId(), destu);
                    destu.friends.put(user.getId(), user);
                }
                message = ContUserMsgController.constructMsg(4, user.getName(), user.getId(), destu.getId(), 0, 0, 0);
                id = messageService.addMessage(message);
                message.setId(id);
                try {
                    jsonObject.put("type", 1);
                    if (user.session != null) {
                        userList.add(destu);
                        jsonObject.put("data", userList);
                        synchronized (user.session) {
                            user.session.getBasicRemote().sendText(jsonObject.toJSONString());
                        }
                        userList.remove(destu);                                                  //所有的这些，用put(x,null)会报错,只能用remove
                    }
                    if (destu.session != null) {
                        userList.add(user);
                        jsonObject.put("data", userList);
                        synchronized (destu.session) {
                            destu.session.getBasicRemote().sendText(jsonObject.toJSONString());
                            jsonObject.put("type", 3);
                            messages = new ArrayList<>();
                            messages.add(message);
                            jsonObject.put("contmsg", messages);
                            jsonObject.put("primsg", null);
                            jsonObject.put("gromsg", null);
                            destu.session.getBasicRemote().sendText(jsonObject.toJSONString());
                        }
                    }
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }
            }
        }
    }


    static void denieFriendship(int send_to,UserContainer userContainer,User user,MessageService messageService){
        Message message ;
        List<Message> messages;
        User destu;
        JSONObject jsonObject = new JSONObject();
        List<Integer> ids;
        int id;

        destu = userContainer.users.get(send_to);
        ids=messageService.checkMsgIsExist(send_to,user.getId(),3);
        if(destu!=null && ids.size()>=1) {
            for(int i : ids) {
                messageService.delMessage(i);      //是send_to发起的
            }
            message = ContUserMsgController.constructMsg(5, user.getName(), user.getId(), send_to, 0, 0, 0);
            id=messageService.addMessage(message);
            try {
                if(destu.session!=null){
                    jsonObject.put("type",3);
                    message.setId(id);
                    messages=new ArrayList<>();
                    messages.add(message);
                    jsonObject.put("contmsg",messages);
                    jsonObject.put("primsg",null);
                    jsonObject.put("gromsg",null);
                    synchronized (destu.session){
                        destu.session.getBasicRemote().sendText(jsonObject.toJSONString());
                    }
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }


    static void cancelFriendship(int send_to,UserContainer userContainer,User user,FriendService friendService,MessageService
                                 messageService){
        Message message ;
        List<Message> messages;
        JSONObject jsonObject = new JSONObject();
        User destu;
        List<Integer> ids;
        int id;

        destu =user.friends.get(send_to);
        ids=friendService.checkFSIsExist(user.getId(),send_to);
        if(destu!=null && ids.size()>=1) {
            friendService.delFriend(user.getId(),send_to);
            friendService.delFriend(send_to,user.getId());
            synchronized (userContainer){
                user.friends.remove(destu.getId());
            }
            if (destu.friends.get(user.getId())!= null) {
                message =ContUserMsgController. constructMsg(6, user.getName(), user.getId(), send_to, 0, 0, 0);
                id = messageService.addMessage(message);
                try {
                    if (destu.session != null) {
                        message.setId(id);
                        messages=new ArrayList<>();
                        messages.add(message);
                        jsonObject.put("type", 3);
                        jsonObject.put("contmsg", messages);
                        jsonObject.put("primsg",null);
                        jsonObject.put("gromsg",null);
                        synchronized (destu.session) {
                            destu.session.getBasicRemote().sendText(jsonObject.toJSONString());
                        }
                    }
                } catch (IOException ioe) {
                    ioe.printStackTrace();
                }
                synchronized (userContainer){
                    destu.friends.remove(user.getId());
                }
            }
        }
    }
}
