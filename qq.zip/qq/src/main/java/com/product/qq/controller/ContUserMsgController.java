package com.product.qq.controller;

import com.alibaba.fastjson.JSONObject;
import com.product.qq.container.UserContainer;
import com.product.qq.dto.Message;
import com.product.qq.dto.User;
import com.product.qq.service.FriendService;
import com.product.qq.service.GroupService;
import com.product.qq.service.MessageService;
import com.product.qq.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;


@RestController
@Controller
public class ContUserMsgController {
    @Autowired
    FriendService friendService;
    @Autowired
    GroupService groupService;
    @Autowired
    UserService userService;
    @Autowired
    MessageService messageService;


    public static Message constructMsg(int type,String content,int user_id,int send_to,int condition,int neg,int pos){
        Message message=new Message();

        message.setType(type);
        message.setStatus(0);
        message.setContent(content);
        message.setUser_id(user_id);
        message.setSend_to(send_to);
        message.setCondition(condition);
        message.setNeg(neg);
        message.setPos(pos);

        return message;
    }
}
