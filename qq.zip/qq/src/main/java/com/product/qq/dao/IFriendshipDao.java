package com.product.qq.dao;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import java.util.List;

public interface IFriendshipDao {
    @Insert("insert into friend(user_id,friend_id)value(#{user_id},#{friend_id})")
    Integer addFriend(@Param("user_id") int user_id, @Param("friend_id") int friend_id);

    @Delete("delete from friend where user_id=#{user_id} and friend_id=#{friend_id} ")
    Integer delFriend(@Param("user_id") int user_id, @Param("friend_id") int friend_id);

    @Select("select id from friend where (user_id=#{user_id} and friend_id=#{friend_id} ) or (friend_id=#{user_id} and user_id=#{friend_id} )")
    List<Integer> checkFSIsExist(@Param("user_id") int user_id, @Param("friend_id") int friend_id);
}
