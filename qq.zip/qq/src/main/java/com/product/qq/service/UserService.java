package com.product.qq.service;

import com.product.qq.dao.IUserDao;
import com.product.qq.dto.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserService implements IUserDao {

    @Autowired
    private IUserDao iUserDao;

    @Override
    public Map<Integer, User> getAllUser() {
        return iUserDao.getAllUser();
    }

    @Override
    public List<Integer> getFriends(Integer id) {
        return iUserDao.getFriends(id);
    }

    @Override
    public List<Integer> getGroups(Integer id) {
        return iUserDao.getGroups(id);
    }

    @Override
    public User getUserById(Integer id) {
        return null;
    }

    @Override
    public List<User> getUserByName(String name) {
        return null;
    }

    @Override
    public User getUserByAcctPwd(String account, String passwd) {
        return null;
    }

    @Override
    public Integer addUser(User user) {
        return iUserDao.addUser(user);
    }

    @Override
    public Integer modifyUser(User user) {
        return null;
    }
}
