package com.product.qq.service;

import com.product.qq.dao.IGroupDao;
import com.product.qq.dto.Group;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class GroupService implements IGroupDao {

    @Autowired
    private IGroupDao iGroupDao;
    @Override
    public Map<Integer, Group> getAllGroup() {
        return iGroupDao.getAllGroup();
    }

    @Override
    public List<Integer> getMembers(Integer id) {
        return iGroupDao.getMembers(id);
    }

    @Override
    public Integer delGroup(int id) {
        return iGroupDao.delGroup(id);
    }

    @Override
    public Integer checkGroupIsExist(String name) {
        return iGroupDao.checkGroupIsExist(name);
    }

    @Override
    public Integer addGroup(Group group) {
        return iGroupDao.addGroup(group);
    }

    @Override
    public Group getGroupById(int id) {
        return iGroupDao.getGroupById(id);
    }
}
