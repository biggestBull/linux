package com.product.qq.service;

import com.product.qq.dao.IFriendshipDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FriendService implements IFriendshipDao {
    @Autowired
    IFriendshipDao iFriendshipDao;

    @Override
    public Integer addFriend(int user_id, int friend_id) {
        return iFriendshipDao.addFriend(user_id,friend_id);
    }

    @Override
    public Integer delFriend(int user_id, int friend_id) {
        return iFriendshipDao.delFriend(user_id,friend_id);
    }

    @Override
    public List<Integer> checkFSIsExist(int user_id, int friend_id) {
        return iFriendshipDao.checkFSIsExist(user_id,friend_id);
    }
}
