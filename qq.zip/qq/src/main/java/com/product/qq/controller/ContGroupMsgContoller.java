package com.product.qq.controller;

import com.alibaba.fastjson.JSONObject;
import com.product.qq.container.GroupContainer;
import com.product.qq.container.UserContainer;
import com.product.qq.dto.Group;
import com.product.qq.dto.Message;
import com.product.qq.dto.User;
import com.product.qq.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.Session;
import java.io.IOException;
import java.util.List;

@Controller
@RestController
public class ContGroupMsgContoller {
    @Autowired
    FriendService friendService;
    @Autowired
    GroupService groupService;
    @Autowired
    UserService userService;
    @Autowired
    MessageService messageService;
    @Autowired
    GroupMemberService groupMemeberService;

    private static UserContainer userContainer;
    private static GroupContainer groupContainer;
    //        #7：加群请求
//    #8：同意加群票
//    #9：拒绝加群票
//    #10：退出群聊
//    #11：解散群

    public static void sendMsg(Session session,String msg){
        if(session!=null){
            try{
                synchronized (session){
                    session.getBasicRemote().sendText(msg);
                }
            }catch (IOException ioe){
                ioe.printStackTrace();
            }
        }
    }
}
