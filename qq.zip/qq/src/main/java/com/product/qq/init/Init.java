package com.product.qq.init;

import com.product.qq.container.GroupContainer;
import com.product.qq.container.UserContainer;
import com.product.qq.dto.Group;
import com.product.qq.dto.User;
import com.product.qq.service.GroupService;
import com.product.qq.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class Init {
    @Autowired
    private GroupService groupService_;

    private static GroupService groupService;
    @Autowired
    private UserService userService_;
    private static UserService userService;

    @PostConstruct
    public void init(){
        groupService=groupService_;
        userService=userService_;
    }

    public static void initGroupUser(){
        GroupContainer groupContainer;
        UserContainer userContainer;
        User user;
        Group group;

        List<Integer> users;
        List<Integer> groups;

        userContainer=UserContainer.getInstance(userService);
        groupContainer= GroupContainer.getInstance(groupService);

        for(Integer key:userContainer.users.keySet()){
            user=userContainer.users.get(key);
            user.friends=new ConcurrentHashMap<>();
            user.groups=new ConcurrentHashMap<>();
            users=userService.getFriends(user.getId());
            groups=userService.getGroups(user.getId());
            for(Integer id:users){
                user.friends.put(id,userContainer.users.get(id));
            }
            for(Integer id : groups){
                user.groups.put(id,groupContainer.groups.get(id));
            }
        }
        for(Integer key : groupContainer.groups.keySet()){
            group=groupContainer.groups.get(key);
            users=groupService.getMembers(key);
            group.member=new ConcurrentHashMap<>();
            for(Integer id : users){
                group.member.put(id,userContainer.users.get(id));
            }
        }

    }
}
