package com.product.qq.dto;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

public class Group implements Serializable {
    private int id;
    private String name;
    private Date date;

    volatile public int isLive=1;
    public Map<Integer,User> member;

    @Override
    public String toString() {
        return "Group{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", date=" + date +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
