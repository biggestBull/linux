package com.product.qq.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.product.qq.container.GroupContainer;
import com.product.qq.container.UserContainer;
import com.product.qq.dto.Message;
import com.product.qq.dto.User;
import com.product.qq.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.List;

@RestController
@Controller
public class MainPageController {
    @Autowired
    MessageService messageService;

    private static UserContainer userContainer;
    private  static GroupContainer groupContainer;

    @GetMapping(value = "/getFriends",produces ="application/json")
    public  String getFriends(HttpServletRequest httpServletRequest) throws IOException {
        userContainer=UserContainer.getInstance();
        groupContainer=GroupContainer.getInstance();
        User user;
        user=(User) httpServletRequest.getSession().getAttribute("user");
        JSONObject jsonObject=new JSONObject();

        System.out.println(httpServletRequest+" <-session"+user);

        System.out.println(JSON.toJSONString(user.friends));
        jsonObject.put("data",user.friends);
        jsonObject.put("type",1);                               //1:添加朋友（到客户端容器）
        synchronized (user.session) {
            user.session.getBasicRemote().sendText(jsonObject.toJSONString());
        }
        return null;
    }

    @GetMapping("/getGroups")
    public String getGroups(HttpServletRequest httpServletRequest) throws IOException{
        userContainer=UserContainer.getInstance();
        groupContainer=GroupContainer.getInstance();
        JSONObject jsonObject=new JSONObject();
        User user;
        user=(User) httpServletRequest.getSession().getAttribute("user");

        jsonObject.put("data",user.groups);
        jsonObject.put("type",2);                               //2:添加群聊（到客户端容器）
        System.out.println(user.session);
        synchronized (user.session) {
            user.session.getBasicRemote().sendText(jsonObject.toJSONString());
        }
        return null;
    }
    @GetMapping("/getNewMsg")
    public String getNewMsg(HttpServletRequest httpServletRequest)throws  IOException{
        userContainer=UserContainer.getInstance();
        groupContainer=GroupContainer.getInstance();
        JSONObject jsonObject=new JSONObject();
        List<Message> umessages,cmessages;
        User user;
        user=(User) httpServletRequest.getSession().getAttribute("user");

        jsonObject.put("type",3);                               //3:添加消息（到客户端容器）
        umessages=messageService.getGenPriMsg(user.getId());
        jsonObject.put("primsg",umessages);
        System.out.println("umessages : "+umessages);

        jsonObject.put("gromsg",null);
        cmessages=messageService.getContMsg(user.getId());
        System.out.println("cmessages : "+cmessages);
        synchronized (user.session){
            user.session.getBasicRemote().sendText(jsonObject.toJSONString());
        }

        return null;
    }

    @GetMapping("/getHistMsg")
    public String getHistMsg(@RequestParam("index")Integer index,@RequestParam("num")int num,@RequestParam("from")int from,@RequestParam("type")int type,HttpServletRequest httpServletRequest){
        userContainer=UserContainer.getInstance();
        groupContainer=GroupContainer.getInstance();
        JSONObject jsonObject=new JSONObject();
        List<Message> umessages,gmessages;
        User user;

        if(index<0 || num <0 || num>100 || from<0)
            return null;
        user=(User) httpServletRequest.getSession().getAttribute("user");

        System.out.println("index:"+index+" num: "+num+" from: "+from+"user_id: "+user.getId()+" type :"+type);
        jsonObject.put("type",4);
        jsonObject.put("msgtype",type);
        if(type==1){
            if(user.friends.get(from)!=null) {
                umessages = messageService.getPriHistMsg(user.getId(), from,index, num);
                System.out.println("1: "+umessages);
                jsonObject.put("primsg",umessages);
                ContGroupMsgContoller.sendMsg(user.session,jsonObject.toJSONString());
            }
        }else if(type ==2){
            if(user.groups.get(from)!=null) {
                gmessages = messageService.getGroHistMsg(from, index, num);
                System.out.println("2: "+gmessages);
                jsonObject.put("gromsg",gmessages);
                ContGroupMsgContoller.sendMsg(user.session,jsonObject.toJSONString());
            }
        }
        return null;
    }

    @GetMapping("update_status")
    public String updataStatus( @RequestParam("id")int id,@RequestParam("type")int type,HttpServletRequest httpServletRequest){
        userContainer=UserContainer.getInstance();
        groupContainer=GroupContainer.getInstance();
        User user;

        user=(User) httpServletRequest.getSession().getAttribute("user");
        if(type==1 && user.friends.get(id)!=null){
            messageService.updateMsgStatus(id,user.getId(),type);
        }
// else if(type==2 && user.groups.get(id)!=null){
//            messageService.updateMsgStatus()
//        }

        return null;
    }

    @GetMapping("/delContMsg")
    public String delContMsg( @RequestParam("from")int from,@RequestParam("type")int type, HttpServletRequest httpServletRequest){
        User user;
        List<Integer> ids;

        user = (User) httpServletRequest.getSession().getAttribute("user");
        ids=messageService.checkMsgIsExist(from,user.getId(),type);
        for(int i : ids){
            messageService.delMessage(i);
        }
        return null;
    }
}
