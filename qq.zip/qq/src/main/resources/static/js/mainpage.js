var wssocket;
var timeout=3000;

var current_type="f";      //群聊or 私聊,默认私聊
var current_id=-1;
var max_msg=10
var current_search_type="f";

alldata={
    "friends":{},
    "groups":{},
    "contmsg":{},
    "histmsg":{},
    "curonline":1
};

userdata={}

var message={
    "id":0,
    "type":0,
    "status":0,
    "content":null,
    "send_to":0,
    "user_id":0,
    "condition":0,
}

function sendMsg(id,type,status,content,send_to,user_id,condition){
    let objString = JSON.stringify(message);
    let message_=JSON.parse(objString);

    message_.content=content;
    message_.type=type;
    message_.id=id;
    message_.status=status;
    message_.send_to=send_to;
    message_.user_id=user_id;
    message_.condition=condition;
    wssocket.send(JSON.stringify(message_));
}

function scrollToBottom(){
    $('#main').scrollTop($('#main')[0].scrollHeight);
}

function request(url) {
    $.ajax({
        type: "GET",
        url: url,
        dataType: "json",
        success: null
    });
}

function getFriends() {
   request("/getFriends");
}
function getGroups() {
    request("/getGroups");
}

function getNewMsg() {
    request("/getNewMsg");
}

function display_controll (event){
    var controll_id_prefix="ugl-item-controll";
    var name_id_prefix="ugl-item-name";
    var dtset=event.target.dataset;
    document.getElementById(controll_id_prefix+dtset.type+dtset.id).style.display="flex";
    document.getElementById(name_id_prefix+dtset.type+dtset.id).style.display="none";
};

function hiddle_controll(event){
    var controll_id_prefix="ugl-item-controll";
    var name_id_prefix="ugl-item-name";
    var dtset=event.target.dataset;
    document.getElementById(controll_id_prefix+dtset.type+dtset.id).style.display="none";
    document.getElementById(name_id_prefix+dtset.type+dtset.id).style.display="block";
}

function change_type(event){
    var dtset=event.target.dataset;
    current_type=dtset.type;

    if(current_type=="f"){
        document.getElementById("friendslist").style.display="block";
        document.getElementById("groupslist").style.display="none";
    }else{
        document.getElementById("friendslist").style.display="none";
        document.getElementById("groupslist").style.display="block";
    }
}

function setTypef(){
    current_search_type="f";
}

function setTypeg(){
    current_search_type="g";
}

function search(){
    let name;
    $("#display_result").css('display','block'); 
    $("#display_groupDetail").css('display','none'); 
    $("#display_userDetail").css('display','none'); 
    name=$("#searchinput").val();
    if(current_search_type=="f"){
        sendMsg(0,3,0,name,0,0,0);
    }else{
        sendMsg(0,8,0,name,0,0,0);
    }
}

function addUG(event){
    let type=event.target.dataset.type;
    let id=event.target.dataset.id;
    if(type==1){
        sendMsg(0,4,0,"gx",id,0,0);
    }else{
        sendMsg(0,9,0,"gx",id,0,0);
    }
    $("#display_resultitem"+id).remove();
}

function createGroup(event){
    sendMsg(0,13,0,event.target.dataset.name,0,0,0);
}


function prichat(event){
    let target=event.target;
    let l,r;
    current_id=target.dataset.id;
    current_type=target.dataset.type;
    $("#fg_name").empty();
    $("#fg_name").append(alldata.friends[current_id].userinfo.name);
    $("#main").empty();
    $("#ugl-item-name_msgf"+current_id).text("");     
    let msgs=alldata.friends[current_id].msgs;
    let content;
    l=alldata.friends[current_id].msgsinfo[1];
    r=alldata.friends[current_id].msgsinfo[2];
    if(l==r && l!=0){
        if(msgs[l].user_id==userdata.id){
            content=`<div  class="msgcls selfmsgcls">
            ${msgs[l].content}</div>`;
        }else{
            content=`<div  class="msgcls othermsgcls">
            ${msgs[l].content}</div>`;
        } 
        putonDiv(content);
        r+=1;
        for(;l!=r;r=(r+1)%alldata.friends[current_id].msgsinfo[0]){
            if(msgs[r].user_id==userdata.id){
                content=`<div  class="msgcls selfmsgcls">
                ${msgs[r].content}</div>`;
            }else{
                content=`<div  class="msgcls othermsgcls">
                ${msgs[r].content}</div>`;
            } 
            putonDiv(content);
        }
    }else{   
        for(;l<r;l++){
            console.log("l+"+l);
            if(msgs[l].user_id==userdata.id){
                content=`<div  class="msgcls selfmsgcls">
                ${msgs[l].content}</div>`;
            }else{
                content=`<div  class="msgcls othermsgcls">
                ${msgs[l].content}</div>`;
            } 
            putonDiv(content);
        }
    }
    request("/update_status"+"?id="+current_id+"&type=1");
    alldata.friends[current_id].new=0;
    scrollToBottom();
}

function grochat(event){
    let target=event.target;
    let l,r;
    current_id=target.dataset.id;
    current_type=target.dataset.type;
    $("#fg_name").empty();
    $("#fg_name").append(alldata.groups[current_id].name);
    $("#main").empty();
    let msgs=alldata.groups[current_id].msgs;
    let content;
    l=alldata.groups[current_id].msgsinfo[1];
    r=alldata.groups[current_id].msgsinfo[2];
    if(l==r && l!=0){
        if(msgs[l].user_id==userdata.id){
            content=`<div  class="msgcls selfmsgcls">
            ${msgs[l].content}</div>`;
        }else{
            content=`<div  class="msgcls othermsgcls">
            ${msgs[l].content}</div>`;
        } 
        putonDiv(content);
        r+=1;
        for(;l!=r;r=(r+1)%alldata.groups[current_id].msgsinfo[0]){
            if(msgs[r].user_id==userdata.id){
                content=`<div  class="msgcls selfmsgcls">
                ${msgs[r].content}</div>`;
            }else{
                content=`<div  class="msgcls othermsgcls">

                ${msgs[r].content}</div>`;
            } 
            putonDiv(content);
        }
    }else{   
        for(;l<r;l++){
            console.log("l+"+l);
            if(msgs[l].user_id==userdata.id){
                content=`<div  class="msgcls selfmsgcls">
                ${msgs[l].content}</div>`;
            }else{
                content=`<div  class="msgcls othermsgcls">
                ${msgs[l].content}</div>`;
            } 
            putonDiv(content);
        }
    }
    request("/update_status"+"?id="+current_id+"&type=1");
    alldata.groups[current_id].new=0;
    scrollToBottom();
}

function displayuserdetail(event){
    console.log(event.target);
    $("#display_result").css('display','none'); 
    $("#display_groupDetail").css('display','none'); 
    $("#display_userDetail").css('display','block'); 

    let friends=alldata.friends[event.target.dataset.id].userinfo;
    let content=`    <span id="display_userDetailname" >Name : ${friends.name}</span><br>
    <span id="display_userDetailage">Age : ${friends.age}</span><br>
    <span id="display_userDetailemail">Email : ${friends.email}</span><br>
    <span id="display_userDetailid">ID : ${friends.id}</span>`;

    $("#display_userDetail").empty();
    $("#display_userDetail").append(content);

}

function displaygroupdetail(event){
    console.log(event.target);
    $("#display_result").css('display','none'); 
    $("#display_groupDetail").css('display','block'); 
    $("#display_userDetail").css('display','none'); 

    let group=alldata.groups[event.target.dataset.id];
    let content=`    <span id="display_groupDetailname">Name : ${group.name}</span><br>
    <span id="display_groupDetailid">ID : ${group.id}</span><br>
    <div id="display_groupDetailmembers"></div>`;

    $("#display_groupDetail").empty();
    $("#display_groupDetail").append(content);
    content="<br>Members:<br> <br>";
    for(var key in group.member){
        content+=`&nbsp;<span id="display_groupDetailmember${group.member[key].id}name">membername : ${group.member[key].name}</span><br></br>`
    }
    $("#display_groupDetailmembers").append(content);
}

function delfriend(evnent){
    console.log(event.target);
    let dataset=event.target.dataset;
  
    $("#f"+dataset.id).remove();
    alldata.friends[dataset.id]=null;

    sendMsg(0,7,0,"del",dataset.id,0,0);
}

function display_user_search_result(data){
    let content;
    $("#display_result").empty();
    for(let key in data){
        let item=data[key];
        content=`    <div id="display_resultitem${item.id}">
        <span >${item.id}</span> | 
        <span >${item.name}</span> | 
        <button class="display_resultitembut" data-id=${item.id} data-type=1 onclick="addUG(event);">添加</button>
    </div>`;
        $("#display_result").append(content);
    }
}

function display_group_search_result(data){
    let content;
    $("#display_result").empty();
    if(data.count==0){
       content=`<button class="display_resultitembut" data-name=${data.group}  onclick="createGroup(event);">创建</button>
    `;
    }else{
        content=`    <div id="display_resultitem${data.group.id}">
        <span >${data.group.id}</span> | 
        <span >${data.group.name}</span> | 
        <button class="display_resultitembut" data-id=${data.group.id} data-type=2 onclick="addUG(event);">添加</button>
    </div>`;
    }
    $("#display_result").append(content);
}

function _addFriends(data){
    for(var key in data){
        console.log("friends "+key);
        let user=data[key];
        alldata.friends[user.id]={};
        alldata.friends[user.id].userinfo=data[key];
        alldata.friends[user.id].msgs=[];
        alldata.friends[user.id].msgs.length=30;
        alldata.friends[user.id].msgsinfo=[max_msg,0,0,0];
        alldata.friends[user.id].new=0;
        let element=`
        <div class="ugl-item" id="f${user.id}" style="display: block;" data-id=${user.id} data-type="f" onmouseenter="display_controll(event);" onmouseleave="hiddle_controll(event);">
            <span id="ugl-item-namef${user.id}" class="ugl-item-namecls" data-id=${user.id} data-type="f">${data[key].name}</span>
        <div id="ugl-item-controllf${user.id}" class="ugl-item-controllcls" style="display: none;">
                <li id="ugl-item-controll-chatf${user.id}" class="ugl-item-controll-buttoncls" data-id=${user.id} data-type="f" onclick="prichat(event);">聊天</li>
                <li id="ugl-item-controll-detailf${user.id}" class="ugl-item-controll-buttoncls" data-id=${user.id} data-type="f" onclick="displayuserdetail(event);">详情</li>
                <li id="ugl-item-controll-deletef${user.id}" class="ugl-item-controll-buttoncls" data-id=${user.id} data-type="f" onclick="delfriend(event);">删除</li>
            </div>
            <span id="ugl-item-name_msgf${user.id}" class="ugl-item-name_msgfcls"></span>
        </div>
   `;
    $("#friendslist").append(element);
    $("#f"+user.id).css("background-color",user.isLive==1?"green":"gray");
    }
}

function _addGroups(data){
    for(var key in data){
        console.log("group "+key);

        alldata.groups[key]={};
        alldata.groups[key].name=data[key].name;
        alldata.groups[key].id=key;
        alldata.groups[key].member=data[key].member;
        alldata.groups[key].msgs=[];
        alldata.groups[key].msgs.length=30;
        alldata.groups[key].msgsinfo=[max_msg,0,0,0];
        alldata.groups[key].new=0;

        let color=data[key].isLive==0?"gray":"green";
        let element=`
        <div class="ugl-item" id="g${key}" style="display: block;background-color:${color}" data-id=${key} data-type="g" onmouseenter="display_controll(event);" onmouseleave="hiddle_controll(event);">
            <span id="ugl-item-nameg${key}" class="ugl-item-namecls" data-id=${key} data-type="g">${data[key].name}</span>
        <div id="ugl-item-controllg${key}" class="ugl-item-controllcls" style="display: none;">
                <li id="ugl-item-controll-chatg${key}" class="ugl-item-controll-buttoncls" data-id=${key} data-type="g" onclick="grochat(event);">聊天</li>
                <li id="ugl-item-controll-detailg${key}" class="ugl-item-controll-buttoncls" data-id=${key} data-type="g" onclick="displaygroupdetail(event);">详情</li>
                <li id="ugl-item-controll-deleteg${key}" class="ugl-item-controll-buttoncls" data-id=${key} data-type="g" onclick="leaveGroup(event);">退出</li>
                <li id="ugl-item-controll-deleteg${key}" class="ugl-item-controll-buttoncls" data-id=${key} data-type="g" onclick="cancelGroup(event);">解散</li>
            </div>
        </div>
`;
    $("#groupslist").append(element);
    }
}

function voteNeg(event){
    let dataset=event.target.dataset;
    sendMsg(dataset.id,10,1,"vote_neg",0,0,dataset.msgid);
    $("#infoitem"+dataset.id).remove();
}

function votePos(event){
    let dataset=event.target.dataset;
    sendMsg(dataset.id,10,0,"vote_pos",0,0,dataset.msgid);
    $("#infoitem"+dataset.id).remove();
}


function delContMsg(from,type){
    request("/delContMsg?from="+from+"&type="+type);
}

function update_status_info(content,type,color){
    $("#eventname").text(content);
    $("#eventtype").text(type);
    $("#eventtype").css("color",color);
}

function agreeFriendShip(event){
    let dataset=event.target.dataset;
    $("#infoitem"+dataset.id).remove();

    sendMsg(0,5,0,"agree",dataset.uid,0,0);
}
function deniedFriendShip(event){
    let dataset=event.target.dataset;
    $("#infoitem"+dataset.id).remove();
    
    sendMsg(0,6,0,"denied",dataset.uid,0,0);
}

function leaveGroup(event){
    sendMsg(0,11,0,"leave",event.target.dataset.id,0,0);
}

function cancelGroup(event){
    sendMsg(0,12,0,"leave",event.target.dataset.id,0,0);
}

function putonDiv(content){
    $("#main").append(content);
}

function display_primsg(item){
    let content;

    if(item.user_id==userdata.id){
        content=`<div  class="msgcls selfmsgcls">
        ${item.content}</div>`;
    }else{
        content=`<div  class="msgcls othermsgcls">
        ${item.content}</div>`;
    } 
    putonDiv(content);  
}

function display_gromsg(item){
    if(item.user_id==userdata.id){
        content=`<div  class="msgcls selfmsgcls">
        ${item.content}</div>`;
    }else{
        content=`<div  class="msgcls othermsgcls">${alldata.groups[item.send_to].member[item.user_id].name}:<br>
        ${item.content}</div>`;
    } 
    putonDiv(content); 
}

function getHistMsg(){
    let index;
    let num;
    index=parseInt($("#his_index").val());
    num=parseInt($("#his_num").val());
    if( num<0 || num>100 || index<0 )
        alert("擦亮眼睛");
    else{
        request("/getHistMsg?index="+index+"&num="+num+"&from="+current_id+"&type="+(current_type=="f"?1:2));
    }
}

function _handleMsg(data){
    var item,temp1,temp2;
    var gromsg=data.gromsg;
    var contmsg=data.contmsg;
    var primsg=data.primsg;

    for(var key in primsg){
        item=primsg[key];
        let id;
        if(userdata.id!=item.user_id){
            id=item.user_id;
        }else{
            id=item.send_to;
        }
        temp1=alldata.friends[id].msgsinfo[1];
        temp2=alldata.friends[id].msgsinfo[2];
        alldata.friends[id].msgs[temp2]=item;
        alldata.friends[id].new+=1;
        if(temp1==temp2 && alldata.friends[id].msgsinfo[3]==1){
            alldata.friends[id].msgsinfo[1]=alldata.friends[id].msgsinfo[2]=(temp1+1)%(alldata.friends[id].msgsinfo[0]);
        }else{
            alldata.friends[id].msgsinfo[2]=(temp2+1)%(alldata.friends[id].msgsinfo[0]);
            alldata.friends[id].msgsinfo[3]=1;
        }    
        if(current_type=="f" && current_id==id){
            display_primsg(item);
        }else if(current_type=="g"){

        }else{

        }  
        let newmsgid="#ugl-item-name_msgf"+id;
        $(newmsgid).text("未读：【 "+alldata.friends[id].new+" 】");
        console.log("new message count"+newmsgid);  
    }
    request("/update_status"+"?id="+current_id+"&type=1");    

    for(var key in gromsg){
        item=gromsg[key];
        console.log("group_send_to "+item.send_to);
        console.log(item);
        temp1=alldata.groups[item.send_to].msgsinfo[1];
        temp2=alldata.groups[item.send_to].msgsinfo[2];
        alldata.groups[item.send_to].msgs[temp2]=item;
        alldata.groups[item.send_to].new+=1;
        if(temp1==temp2 && alldata.groups[item.send_to].msgsinfo[3]==1){
            alldata.groups[item.send_to].msgsinfo[1]=alldata.groups[item.send_to].msgsinfo[2]=(temp1+1)%(alldata.groups[item.send_to].msgsinfo[0]);
        }else{
            alldata.groups[item.send_to].msgsinfo[2]=(temp2+1)%(alldata.groups[item.send_to].msgsinfo[0]);
            alldata.groups[item.send_to].msgsinfo[3]=1;
        }
        let content;
        if(current_type=="g" && current_id==item.send_to){
            display_gromsg(item);
        }else if(current_type=="g"){

        } else{

        }
    }
    scrollToBottom();
    for(var key in contmsg){
        let content;
        alldata.contmsg[key]=contmsg[key];
        console.log(contmsg[key]);

        switch(contmsg[key].type){
            case 3:
                content=`    <div id="infoitem${contmsg[key].id}" class="infoitemcls">
                <span id="from${contmsg[key].id}">${contmsg[key].content}</span>
                <span id="illustration${contmsg[key].id}">请求</span>
                <span id="infotype${contmsg[key].id}">添加好友</span>
                <div id="infobut${contmsg[key].id}">
                    <div class="okcls" data-id=${contmsg[key].id} data-uid=${contmsg[key].user_id} data-msgid=${contmsg[key].condition} onclick="agreeFriendShip(event);" style="display: inline-block;">OK</div>
                    <div class="nocls"  data-id=${contmsg[key].id} data-uid=${contmsg[key].user_id} data-msgid=${contmsg[key].condition} onclick="deniedFriendShip(event);" style="display: inline-block;">No</div>
                </div>
            </div>`;
                break;
            case 4:
                update_status_info(contmsg[key].content,"添加好友","green");
                delContMsg(contmsg[key].user_id,4);
                break;
            case 5:
                update_status_info(contmsg[key].content,"添加好友","red");
                delContMsg(contmsg[key].user_id,5);
                break;
            case 6:
                update_status_info(contmsg[key].content,"解除好友","red");
                $("#f"+contmsg[key].user_id).remove();
                alldata.friends[contmsg[key].user_id]=null;
                delContMsg(contmsg[key].user_id,6);
                break;
            case 7:
                content=`    <div id="infoitem${contmsg[key].id}" class="infoitemcls">
                <span id="from${contmsg[key].id}">${contmsg[key].content.split(",")[0]}</span>
                <span id="illustration${contmsg[key].id}">请求</span>
                <span id="infotype${contmsg[key].id}">加群[${contmsg[key].content.split(" ")[1]}]</span>
                <div id="infobut${contmsg[key].id}">
                    <div class="okcls" data-id=${contmsg[key].id} data-uid=${contmsg[key].user_id} data-msgid=${contmsg[key].condition} onclick="votePos(event);" style="display: inline-block;">OK</div>
                    <div class="nocls"  data-id=${contmsg[key].id} data-uid=${contmsg[key].user_id} data-msgid=${contmsg[key].condition}  onclick="voteNeg(event);" style="display: inline-block;">No</div>
                </div>
            </div>`;
                break;
            case 10:
                console.log("jiesan qun");
                if(contmsg[key].content!=undefined){
                    update_status_info(contmsg[key].content.split(",")[0]+" ["+contmsg[key].content.split(",")[1]+"]","解散","red");
                    delContMsg(contmsg[key].user_id,10);
                }
                break;
            case 50:
                console.log("haoyou shangxian");
                $("#f"+contmsg[key].user_id).css("background-color","green");
                update_status_info(alldata.friends[contmsg[key].user_id].userinfo.name,"上线","green");
                break;
            case 51:
                console.log("haoyou xiaxian");
                $("#f"+contmsg[key].user_id).css("background-color","gray");
                update_status_info(alldata.friends[contmsg[key].user_id].userinfo.name,"下线","black");
                break;
            case 52:
                console.log("qunyou shangxian");
                break;
            case 53:
                console.log("qunyou xiaxian");
                break;
            case 54:
                console.log("jiaqun chenggong");
                update_status_info(contmsg[key].content,"加群","green");
                delContMsg(contmsg[key].user_id,54);
                break;
            case 55:
                console.log("jiaqun shibai");
                update_status_info(contmsg[key].content,"加群","red");
                delContMsg(contmsg[key].user_id,55);
                break;
            case 56:
                console.log("qunyou tuichu");
                update_status_info(contmsg[key].content,"退群","red");
                delContMsg(contmsg[key].user_id,56);
                break;
            case 57:
                console.log("jianqun chenggong");
                update_status_info(contmsg[key].content,"建群","green");
                delContMsg(contmsg[key].user_id,57);
                break;
            case 58:
                console.log("jianqun shibai");
                update_status_info(contmsg[key].content,"建群","red");
                delContMsg(contmsg[key].user_id,58);
                break;
            case 59:
                alert("系统群数量以达上限");
        }
        $("#info").append(content);
    }

}

$(document).ready(function(){

    if(typeof(WebSocket) == "undefined") {
        console.log("您的浏览器不支持WebSocket");
    }else{
        console.log("您的浏览器支持WebSocket");
        //实现化WebSocket对象，指定要连接的服务器地址与端口  建立连接
        //等同于
        wssocket = new WebSocket("ws://localhost:8081/chat");
        //socket = new WebSocket("${basePath}websocket/${cid}".replace("http","ws"));
        //打开事件
        wssocket.onopen = function() {
            console.log("Socket 已打开");
            //socket.send("这是来自客户端的消息" + location.href + new Date());
        };
        //获得消息事件
        wssocket.onmessage = function(msg) {
            var jsonobj = eval('(' + msg.data + ')');
            console.log(jsonobj);
            switch(jsonobj.type){
                case 0:
                    userdata=jsonobj.data;
                    alldata.curonline=jsonobj.curonline;
                    console.log("userdata");
                    console.log(userdata);
                    $("#userid").text("ID: "+userdata.id);
                    $("#username").text("Name: "+userdata.name);
                    $("#account").text("Account: "+userdata.account);
                    $("#email").text("Email: "+userdata.email);
                    $("#age").text("Age: "+userdata.age);
                    break;
                case 1:
                    _addFriends(jsonobj.data);
                    break;
                case 2:
                    _addGroups(jsonobj.data);
                    break;
                case 3:
                    _handleMsg(jsonobj);
                    break;
                case 4:
                    console.log("historyMsg");
                    $("#main").empty();
                    switch(jsonobj.msgtype){
                        case 1:
                            for(let key in jsonobj.primsg){
                                let item=jsonobj.primsg[key];
                                display_primsg(item);
                            }
                            break;
                        case 2:
                            for(let key in jsonobj.gromsg){
                                let item=jsonobj.gromsg[key];
                                display_gromsg(item);
                            }
                        }
                        scrollToBottom();
                    break;
                case 5:
                    console.log(jsonobj.users);
                    display_user_search_result(jsonobj.users);
                    break;
                case 6:
                    console.log(jsonobj);
                    display_group_search_result(jsonobj);
            }
            console.log(alldata);
        };
        //关闭事件
        wssocket.onclose = function(e) {
            console.log("Socket已关闭");
            console.log(e);
        };
        //发生了错误事件
        wssocket.onerror = function() {
            alert("Socket发生了错误");
            //此时可以尝试刷新页面
        }
    }
});

$(document).ready(setTimeout(function () {
    getFriends();
    getGroups();
    getNewMsg();
},3000));

$(document).ready(setTimeout(function(){
    $(document).keydown(function (event) { 
        if (event.ctrlKey && event.keyCode == 13) { 
                let content=$("#msg_input").val();
                let objString = JSON.stringify(message);
                let message_=JSON.parse(objString);
                message_.content=content;
                message_.type=current_type=="f"?1:2;
                message_.send_to=current_id;
                console.log("current_id "+current_id);
                message_.user_id=userdata.id;
                wssocket.send(JSON.stringify(message_));

                console.log(content);
                $("#msg_input").val("");
                if(content!="null"){

                    if(current_type=="f"){
                        content=`<div class="msgcls selfmsgcls">
                        ${content}</div>`;
                        let temp1=alldata.friends[current_id].msgsinfo[1];
                        let temp2=alldata.friends[current_id].msgsinfo[2];
                        alldata.friends[current_id].msgs[temp2]=message_;
                        if(temp1==temp2 && alldata.friends[current_id].msgsinfo[3]==1){
                            alldata.friends[current_id].msgsinfo[1]=alldata.friends[current_id].msgsinfo[2]=(temp1+1)%(alldata.friends[current_id].msgsinfo[0]);
                        }else{
                            alldata.friends[current_id].msgsinfo[2]=(temp2+1)%(alldata.friends[current_id].msgsinfo[0]);
                            alldata.friends[current_id].msgsinfo[3]=1;
                        }
                        request("/update_status"+"?id="+current_id+"&type=1");  
                        putonDiv(content);
                    }
                    //群聊等服务器群发
                    scrollToBottom();
             }
    
         };
         return true;}
    );
},5000));


