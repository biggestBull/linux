function toRegister(){
    var Login=document.getElementById("Login");
    var Register=document.getElementById("Register");
    Login.style.display="none";
    Register.style.display="block";

}
function toLogin(){
    var Login=document.getElementById("Login");
    var Register=document.getElementById("Register");
    Login.style.display="block";
    Register.style.display="none";

}

function Login(){
    var _loginform=document.forms["loginform"];
    var requestParam='';

    for(i=0;i<_loginform.elements.length-1;i++){
        var name=_loginform.elements[i].name;
        var value=_loginform.elements[i].value;

        if(value==""){
            alert(name+"不能为空！");
            return ;
        }
        if(i!=0)
            requestParam+="&";
        requestParam+=name+"="+value;
    }
    console.log(requestParam);
    $.ajax({
        type: "POST",
        url: "/login",
        data:requestParam,
        dataType: "text",
        success: function(data){
            console.log(data);
            switch(data){
                case "APError":
                    alert("账号或密码错误");
                    break;
                case "ParamError":
                    alert("参数错误");
                    break;
                default:
                    window.location.href=data;
            }
        }
    });
}
function Register(){
    var _registerform=document.forms["registerform"];
    var requestParam='';

    for(i=0;i<_registerform.elements.length-1;i++){
        var name=_registerform.elements[i].name;
        var value=_registerform.elements[i].value;

        if(value==""){
            if(name!="email"){
                alert(name+"不能为空！");
                return ;
            }
        }
        if(i!=0)
            requestParam+="&";
        requestParam+=name+"="+value;
    }
    console.log(requestParam);
    $.ajax({
        type: "POST",
        url: "/register",
        data:requestParam,
        dataType: "text",
        success: function(data){
            console.log(data);
            switch(data){
                case "APError":
                    alert("账号或密码错误");
                    break;
                case "ParamError":
                    alert("参数错误");
                    break;
                case "UserRegLimit":
                    alert("系统用户数以达上限");
                default:
                    window.location.href=data;
            }
        }
    });
}