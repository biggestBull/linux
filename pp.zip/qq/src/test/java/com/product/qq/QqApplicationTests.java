package com.product.qq;

import com.product.qq.container.GroupContainer;
import com.product.qq.container.UserContainer;
import com.product.qq.dto.Group;
import com.product.qq.dto.User;
import com.product.qq.init.Init;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class QqApplicationTests {

    //@Test
    void getUsers() {
        UserContainer userContainer;
        GroupContainer groupContainer;
        User user,friend;
        Group group;

        Init.initGroupUser();
        userContainer=UserContainer.getInstance();
        groupContainer=GroupContainer.getInstance();


        System.out.println("users:");
        for(Integer key: userContainer.users.keySet()){
            user=userContainer.users.get(key);
            System.out.println("--user:"+user.getName());
            for(Integer id: user.friends.keySet()){
                friend=user.friends.get(id);
                System.out.println("\tfriend:"+friend.getName());
            }
            for(Integer id:user.groups.keySet()){
                group=user.groups.get(id);
                System.out.println("\tgroup:"+group.getName());
            }
        }
        System.out.println("groups:");
        for(Integer key:groupContainer.groups.keySet()){
            group=groupContainer.groups.get(key);
            System.out.println("--group:"+group.getName());
            for(Integer id:group.member.keySet()){
                user=group.member.get(id);
                System.out.println("\tmember:"+user.getName());
            }
        }
    }

}
