package com.product.qq.dto;

import com.alibaba.fastjson.annotation.JSONField;

import java.io.Serializable;
import java.util.Date;

public class Message implements Serializable {
    private int id;
    private int type;
    private int status;
    private String content;
    private Date created_time;
    private int user_id;
    private int send_to;
    //@JSONField(serialize = false)
    private int condition;
    //@JSONField(serialize = false)
    private int pos;
    //@JSONField(serialize = false)
    private int neg;


    @Override
    public String toString() {
        return "Message{" +
                "id=" + id +
                ", type=" + type +
                ", status=" + status +
                ", content='" + content + '\'' +
                ", created_time=" + created_time +
                ", user_id=" + user_id +
                ", send_to=" + send_to +
                '}';
    }

    public int getCondition() {
        return condition;
    }

    public void setCondition(int condition) {
        this.condition = condition;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }

    public int getNeg() {
        return neg;
    }

    public void setNeg(int neg) {
        this.neg = neg;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getCreated_time() {
        return created_time;
    }

    public void setCreated_time(Date created_time) {
        this.created_time = created_time;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public int getSend_to() {
        return send_to;
    }

    public void setSend_to(int send_to) {
        this.send_to = send_to;
    }
}
