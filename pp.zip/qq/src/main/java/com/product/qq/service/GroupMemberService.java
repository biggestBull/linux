package com.product.qq.service;

import com.product.qq.dao.IGroupMemberDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GroupMemberService implements IGroupMemberDao {
    @Autowired
    IGroupMemberDao iGroupMemeberDao;

    @Override
    public Integer checkMemeberIsExist( int user_id, int group_id) {
        return iGroupMemeberDao.checkMemeberIsExist(user_id,group_id);
    }

    @Override
    public Integer delMemeber(int uid,int gid) {
        return iGroupMemeberDao.delMemeber(uid,gid);
    }

    @Override
    public Integer delAllMember(int group_id) {
        return iGroupMemeberDao.delAllMember(group_id);
    }

    @Override
    public Integer addMember(int gid, int uid) {
        return iGroupMemeberDao.addMember(gid,uid);
    }
}
