package com.product.qq.service;

import com.alibaba.fastjson.JSONObject;
import com.product.qq.config.WebSocketConfiguration;
import com.product.qq.container.GroupContainer;
import com.product.qq.container.UserContainer;
import com.product.qq.dto.Group;
import com.product.qq.dto.Message;
import com.product.qq.dto.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.servlet.http.HttpSession;
import javax.websocket.*;
import javax.websocket.server.ServerEndpoint;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;


@Service
@ServerEndpoint(value = "/chat",configurator= WebSocketConfiguration.class)
public class WebSocketServer {
    private  Message message;
    private HttpSession httpSession;
    private static int maxconnection;
    private static  int maxgroup;
    private  AtomicInteger curonline=new AtomicInteger();
    private static MessageService messageService;
    private static FriendService friendService;
    private static GroupService groupService;
    private static UserService userService;
    private static GroupMemberService groupMemberService;
    private User user;

    @Autowired
    public void setService(GroupService g,MessageService m,UserService u,FriendService f,GroupMemberService gm){
        messageService=m;
        friendService=f;
        groupService=g;
        userService=u;
        groupMemberService=gm;
    }

    @Value("${qq.maxconnection}")
    public void setMaxconnection(int _mc){
        maxconnection=_mc;
    }
    @Value("${qq.maxgroup}")
    public void setMaxgroup(int _mg){
        maxgroup=_mg;
    }
    @OnOpen
    public void onOpen(Session session,EndpointConfig config) throws IOException{
        message=new Message();
        JSONObject jsonObject=new JSONObject();

        System.out.println("max: "+maxconnection);
        httpSession= (HttpSession) config.getUserProperties().get(HttpSession.class.getName());
        System.out.println( httpSession.getAttribute("user"));

        if(httpSession.getAttribute("user")==null || curonline.get()>=maxconnection){
            try {
                System.out.println("close session");
                synchronized(session) {
                    session.close();
                }

            }catch (IOException ioe){
                ioe.printStackTrace();
            }
            return ;
        }
        System.out.println("session:"+session+"httpsession:"+httpSession);
        user=(User)(httpSession.getAttribute("user"));
        user.session=session;
        user.setIsLive(1);
        jsonObject.put("type",0);
        jsonObject.put("data",user);
        jsonObject.put("curonline",curonline.incrementAndGet());
        synchronized (session){
            session.getBasicRemote().sendText(jsonObject.toJSONString());     //发送用户信息
        }
        WebSocketUser.notifyUG(user,1);
    }

    @OnMessage
    public void onMessage(String msg,Session session){
        JSONObject jsonObject = JSONObject.parseObject(msg);
        String content;
        int  send_to, type,user_id,id,status,condition;

        System.out.println("on message0"+msg);
        content = jsonObject.getString("content");
        if(content==null)
            return;
        send_to = Integer.parseInt(jsonObject.getString(("send_to")));
        condition = Integer.parseInt(jsonObject.getString(("condition")));
        type = Integer.parseInt(jsonObject.getString("type"));
        user_id = Integer.parseInt(jsonObject.getString(("user_id")));
        id = Integer.parseInt(jsonObject.getString("id"));
        status = Integer.parseInt(jsonObject.getString(("status")));
        content=jsonObject.getString("content");
        message.setType(type);
        message.setContent(content);
        message.setSend_to(send_to);
        message.setUser_id(user_id);
        message.setId(id);
        message.setStatus(status);
        message.setCondition(condition);

        System.out.println("onmessage:"+message);
        sendMsgHandler(message);
    }

    @OnError
    public  void onError(Throwable e, Session session){
        try{
            user.session=null;
            user.setIsLive(0);
            curonline.decrementAndGet();
            WebSocketUser.notifyUG(user,0);
            e.printStackTrace();
        }catch (NullPointerException npe){
            npe.printStackTrace();
        }
    }

    @OnClose
    public  void onClose(){
        System.out.println(user.getName()+" close!");
        try {
            user.session=null;
            user.setIsLive(0);
            curonline.decrementAndGet();
            WebSocketUser.notifyUG(user,0);
        }catch (NullPointerException npe){
            npe.printStackTrace();
        }

    }

    private void handleGenMsg(Message message, User user, Session session,int type){
        JSONObject jsonObject=new JSONObject();
        List<Message> messageList=new ArrayList<>();

        jsonObject.put("type",3);
        message.setStatus(0);
        System.out.println(message);
        if(type==1) {
            message.setUser_id(user.getId());
            messageService.addMessage(message);
            message = messageService.getMessageById(message.getId());
        }
        messageList.add(message);
        jsonObject.put("primsg",type==1?messageList:null);
        jsonObject.put("gromsg",type==2?messageList:null);
        jsonObject.put("contmsg",null);
        try{
            if(session!=null) {
                synchronized (session) {
                    session.getBasicRemote().sendText(jsonObject.toJSONString());
                }
            }
        }catch (IOException ioe){
            ioe.printStackTrace();
        }
    }

    private void sendMsgHandler(Message message){
        User destu;
        Group destg;

        destu=user.friends.get(message.getSend_to());
        destg=user.groups.get(message.getSend_to());
        switch (message.getType()){
            case 1:
                System.out.println("1");
                if(destu!=null){
                    handleGenMsg(message,user,destu.session,1);
                }
                break;
            case 2:
                System.out.println("2");
                if(destg!=null){
                    message.setUser_id(user.getId());
                    messageService.addMessage(message);
                    message = messageService.getMessageById(message.getId());
                    for(Integer id : destg.member.keySet()){
                        destu=destg.member.get(id);
                        handleGenMsg(message,user,destu.session,2);
                    }
                }
                break;
            case 3:                                                             //以下皆控制消息
                WebSocketUser.searchUser(message.getContent(),UserContainer.getInstance(),user);
                break;
            case 4:
                WebSocketUser.addFriend(message.getSend_to(),UserContainer.getInstance(),user,messageService);
                break;
            case 5:
                WebSocketUser.agreeFriendship(message.getSend_to(),UserContainer.getInstance(),user,messageService,friendService);
                break;
            case 6:
                WebSocketUser.denieFriendship(message.getSend_to(),UserContainer.getInstance(),user,messageService);
                break;
            case 7:
                WebSocketUser.cancelFriendship(message.getSend_to(),UserContainer.getInstance(),user,friendService,messageService);
                break;
            case 8:
                WebSocketGroup.searchGroup(message.getContent(), GroupContainer.getInstance(),user);
                break;
            case 9:
                WebSocketGroup.addGroup(message.getSend_to(),GroupContainer.getInstance(),user,messageService);
                break;
            case 10:
                WebSocketGroup.arbitrateAddGroup(message.getCondition(),message.getStatus(),message.getId(),GroupContainer.getInstance(),UserContainer.getInstance(),user,messageService,groupMemberService);
                break;
            case 11:
                WebSocketGroup.leaveGroup(message.getSend_to(),user,groupMemberService,messageService);
                break;
            case 12:
                WebSocketGroup.cancelGroup(message.getSend_to(),GroupContainer.getInstance(),user,groupMemberService,messageService,groupService
                );
                break;
            case 13:
                WebSocketGroup.createGroup(message.getContent(),maxgroup,GroupContainer.getInstance(),user,groupService,groupMemberService);
                break;
        }
    }
}
