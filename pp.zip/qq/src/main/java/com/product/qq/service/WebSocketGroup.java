package com.product.qq.service;

import com.alibaba.fastjson.JSONObject;
import com.product.qq.container.GroupContainer;
import com.product.qq.container.UserContainer;
import com.product.qq.controller.ContGroupMsgContoller;
import com.product.qq.controller.ContUserMsgController;
import com.product.qq.dto.Group;
import com.product.qq.dto.Message;
import com.product.qq.dto.User;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

class WebSocketGroup {
    static void searchGroup(String name, GroupContainer groupContainer,User user){
        Group destg=null;
        JSONObject jsonObject=new JSONObject();

        for(Integer key : groupContainer.groups.keySet()){
            destg=groupContainer.groups.get(key);
            if(destg.getName().equals(name) && user.groups.get(key)==null){
                break;
            }
            destg=null;
        }
        jsonObject.put("type",6);
        jsonObject.put("group",destg==null?name:destg);
        jsonObject.put("count",destg==null?0:1);
        ContGroupMsgContoller.sendMsg(user.session,jsonObject.toJSONString());
        System.out.println("searchGroup");
    }

    static void addGroup(int send_id,GroupContainer groupContainer,User user,MessageService messageService){
        User destu;
        Group destg;
        Message message;
        List<Message> messages;
        JSONObject jsonObject=new JSONObject();
        List<Integer> ids;
        int id;

        destg=groupContainer.groups.get(send_id);
        ids=messageService.checkMsgIsExist(user.getId(),send_id,59);
        if(destg!=null && user.groups.get(send_id)==null ){
            if(ids.size()==0){
                message= ContUserMsgController.constructMsg(59,null,user.getId(),send_id,destg.member.size()/2+1,0,0);
                messageService.addMessage(message);               //返回id（见xml）
                message.setContent(user.getName()+","+destg.getName());
                id=message.getId();
            }else{
                System.out.println("addgroup has exist!");
                message=messageService.getMessageById(ids.get(0));
                if(message.getCondition()<=message.getPos() || message.getCondition()<=message.getNeg()){
                    if(new Date().getTime()>message.getCreated_time().getTime()+(1000*60*60*12*3)){
                        messageService.delMessage(ids.get(0));
                    }
                }
                return ;
            }
            jsonObject.put("type",3);
            for(Integer i : destg.member.keySet()){
                destu=destg.member.get(i);
                if(destu==null)
                    continue;
                message.setSend_to(destu.getId());
                message.setType(7);
                message.setStatus(send_id);
                message.setCondition(id);
                messageService.addMessage(message);
                if(destu.session!=null) {
                    messages=new ArrayList<>();
                    messages.add(message);
                    jsonObject.put("contmsg",messages);
                    jsonObject.put("primsg",null);
                    jsonObject.put("gromsg",null);
                    ContGroupMsgContoller.sendMsg(destu.session,jsonObject.toJSONString());
                }
            }
        }
    }

    static void arbitrateAddGroup(int msgid,int vote,int realid, GroupContainer groupContainer, UserContainer userContainer, User user, MessageService messageService,GroupMemberService groupMemberService){
        User destu;
        Group destg;
        Message message;
        List<Message> messages;
        JSONObject jsonObject=new JSONObject();
        int id;

        message=messageService.getMessageById(msgid);
        if(message!=null && message.getType()==59 && user.groups.get(message.getSend_to())!=null){
            destu=userContainer.users.get(message.getUser_id());
            destg=groupContainer.groups.get(message.getSend_to());
            jsonObject.put("type",3);
            if(vote==0){
                System.out.println("vote0");
                messageService.incrementMsgPos(msgid);
                message.setPos(message.getPos()+1);
            }else{
                System.out.println("vote1");
                messageService.incrementMsgNeg(msgid);
                message.setNeg(message.getNeg()+1);
            }
            if(message.getPos()>=message.getCondition()){
                message=ContUserMsgController.constructMsg(54,destg.getName(),user.getId(),destu.getId(),0,0,0);
                id=messageService.addMessage(message);
                groupMemberService.addMember(destg.getId(),destu.getId());
                if(destu.session!=null) {
                    message.setId(id);
                    jsonObject.put("primsg",null);
                    jsonObject.put("gromsg",null);
                    messages=new ArrayList<>();
                    messages.add(message);
                    jsonObject.put("contmsg",messages);
                    ContGroupMsgContoller.sendMsg(destu.session, jsonObject.toJSONString());
                }
                destu.groups.put(destg.getId(),destg);
                destg.member.put(destu.getId(),destu);
            }else if(message.getNeg()>=message.getCondition()){
                message=ContUserMsgController.constructMsg(55,destg.getName(),user.getId(),destu.getId(),0,0,0);
                id=messageService.addMessage(message);
                if(destu.session!=null) {
                    messages=new ArrayList<>();
                    message.setId(id);
                    messages.add(message);
                    jsonObject.put("primsg",null);
                    jsonObject.put("gromsg",null);
                    jsonObject.put("contmsg",messages);
                    ContGroupMsgContoller.sendMsg(destu.session, jsonObject.toJSONString());
                }
            }
        }
        messageService.delMessage(realid);
    }

    static void leaveGroup(int send_to,User user,GroupMemberService groupMemberService,MessageService messageService){
        User destu;
        Group destg;
        Message message;
        JSONObject jsonObject=new JSONObject();
        List<Message> messages;
        int cnt,id;

        cnt=groupMemberService.checkMemeberIsExist(user.getId(),send_to);
        if(cnt==1 || user.groups.get(send_to)!=null){
            destg=user.groups.get(send_to);
            groupMemberService.delMemeber(user.getId(),send_to);
            user.groups.remove(send_to);
            jsonObject.put("type",3);
            message=ContUserMsgController.constructMsg(56,user.getName(),user.getId(),send_to,0,0,0);
            id=messageService.addMessage(message);
            message.setId(id);
            messages=new ArrayList<>();
            messages.add(message);
            jsonObject.put("contmsg",messages);
            jsonObject.put("primsg",null);
            jsonObject.put("gromsg",null);
            for(Integer key:destg.member.keySet()){
                destu=destg.member.get(key);
                if(destu==user){
                    destg.member.remove(key);
                    continue;
                }
                ContGroupMsgContoller.sendMsg(destu.session,jsonObject.toJSONString());
            }
        }
    }

    static void cancelGroup(int send_to,GroupContainer groupContainer,User user,GroupMemberService groupMemberService,MessageService messageService,GroupService groupService){
        User destu;
        Group destg;
        Message message;
        List<Message> messages;
        JSONObject jsonObject=new JSONObject();
        int id;

        destg=user.groups.get(send_to);
        id=groupMemberService.checkMemeberIsExist(user.getId(),send_to);
        if(id==1 && destg!=null){
            groupContainer.groups.remove(send_to);
            groupService.delGroup(send_to);
            groupMemberService.delAllMember(send_to);

            jsonObject.put("type",3);
            message=ContUserMsgController.constructMsg(10,user.getName()+","+destg.getName(),user.getId(),0,0,0,0);
            messages=new ArrayList<>();
            for(Integer key:destg.member.keySet()){
                messages.add(message);
                destu=destg.member.get(key);
                message.setSend_to(destu.getId());
                destu.groups.remove(send_to);
                id=messageService.addMessage(message);
                message.setId(id);
                jsonObject.put("contmsg",messages);
                jsonObject.put("primsg",null);
                jsonObject.put("gromsg",null);
                ContGroupMsgContoller.sendMsg(destu.session,jsonObject.toJSONString());
            }
        }
    }

    static void createGroup(String name,int maxgroup,GroupContainer groupContainer,User user,GroupService groupService,GroupMemberService groupMemberService){
        Message message;
        List<Message> messages=new ArrayList<>();
        List<Group> groups;
        JSONObject jsonObject=new JSONObject();
        int count,id;
        Group new_group;

        if(groupContainer.groups.size()>maxgroup){
            message=ContUserMsgController.constructMsg(59,name,user.getId(),user.getId(),0,0,0);
            messages.add(message);
            jsonObject.put("contmsg",messages);
            ContGroupMsgContoller.sendMsg(user.session,jsonObject.toJSONString());
        }

        count=groupService.checkGroupIsExist(name);
        jsonObject.put("primsg",null);
        jsonObject.put("grosg",null);
        jsonObject.put("type",3);
        if(count==0){
            new_group=new Group();
            new_group.setName(name);
            groupService.addGroup(new_group);
            id=new_group.getId();
            groupMemberService.addMember(id,user.getId());

            new_group=groupService.getGroupById(id);
            new_group.member=new ConcurrentHashMap<>();
            new_group.member.put(user.getId(),user);
            user.groups.put(id,new_group);
            groupContainer.groups.put(id,new_group);
            if(user.session!=null){
                message=ContUserMsgController.constructMsg(57,name,user.getId(),user.getId(),0,0,0);
                messages.add(message);
                jsonObject.put("contmsg",messages);
                ContGroupMsgContoller.sendMsg(user.session,jsonObject.toJSONString());
                groups=new ArrayList<>();
                groups.add(new_group);
                jsonObject.put("type",2);
                jsonObject.put("data",groups);
                ContGroupMsgContoller.sendMsg(user.session,jsonObject.toJSONString());
            }
        }else{
            message=ContUserMsgController.constructMsg(58,name,user.getId(),user.getId(),0,0,0);
            messages.add(message);
            jsonObject.put("contmsg",messages);
            ContGroupMsgContoller.sendMsg(user.session,jsonObject.toJSONString());
        }
    }
}
