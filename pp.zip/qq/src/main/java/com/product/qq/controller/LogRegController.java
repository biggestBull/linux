package com.product.qq.controller;

import com.product.qq.container.UserContainer;
import com.product.qq.dto.User;
import com.product.qq.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.http.HttpSession;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@Controller
public class LogRegController {
    @Autowired
    private UserService userService;

    @Value("${qq.maxuser}")
    private Integer maxuser;

    @PostMapping("/login")
    public String login(@RequestParam("account") String account, @RequestParam("passwd") String pwd, HttpSession httpSession) {
        UserContainer userContainer= UserContainer.getInstance();
        User user;

        if(account.equals("") || pwd.equals(""))
            return "ParamError";
        for(Integer id:userContainer.users.keySet()){
            user=userContainer.users.get(id);
            if(account.equals(user.getAccount())){
                if(pwd.equals(user.getPasswd())){
                    httpSession.setAttribute("user",user);
                    return "/html/mainPage.html";
                }
                break;
            }
        }
        return "APError";
    }

    @PostMapping("/register")
    public String register(@RequestParam("name") String name,@RequestParam("age") String age,@RequestParam("email")
                           String email,@RequestParam("account") String account,@RequestParam("passwd") String pwd,
                           HttpSession httpSession){
        UserContainer userContainer= UserContainer.getInstance();
        User user;

        if(UserContainer.getInstance().users.size()>maxuser)
            return "UserRegLimit";

        if(name.equals("") || age.equals("") || account.equals("") || pwd.equals(""))
            return "ParamError";

        for(Integer id:userContainer.users.keySet()){
            user=userContainer.users.get(id);
            if(account.equals(user.getAccount()))
                return "APError";
        }
        user=new User();
        user.setName(name);
        user.setAge(Integer.parseInt(age));
        user.setEmail(email);
        user.setAccount(account);
        user.setPasswd(pwd);

        user.groups=new ConcurrentHashMap<>();
        user.friends=new ConcurrentHashMap<>();
        userService.addUser(user);
        System.out.println("id:"+user.getId());
        userContainer.users.put(user.getId(),user);
        httpSession.setAttribute("user",user);
        return "/html/mainPage.html";
    }
}
