package com.product.qq.dto;

import com.alibaba.fastjson.annotation.JSONField;

import javax.websocket.Session;
import java.io.Serializable;
import java.util.Date;
import java.util.Map;


public class User implements Serializable {
    private int id;
    private String name;
    private  int age;
    private String email;
    private String account;

    @JSONField(serialize = false)
    private String passwd;

    private Date created_time;
    private Date recently_login;
    private int isLive=0;

    public int getIsLive() {
        return isLive;
    }

    public void setIsLive(int isLive) {
        this.isLive = isLive;
    }

    @JSONField(serialize = false)
    volatile public Session session=null;

    @JSONField(serialize = false)
    public Map<Integer,User> friends;
    @JSONField(serialize = false)
    public Map<Integer,Group> groups;


    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getCreated_time() {
        return created_time;
    }

    public void setCreated_time(Date created_time) {
        this.created_time = created_time;
    }

    public Date getRecently_login() {
        return recently_login;
    }

    public void setRecently_login(Date recently_login) {
        this.recently_login = recently_login;
    }


    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", email='" + email + '\'' +
                ", created_time=" + created_time +
                ", recently_login=" + recently_login +
                '}';
    }
}
