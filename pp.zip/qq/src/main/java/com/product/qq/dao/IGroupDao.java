package com.product.qq.dao;

import com.product.qq.dto.Group;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

public interface IGroupDao {
    @MapKey("id")
    Map<Integer, Group> getAllGroup();
    List<Integer> getMembers(Integer id);

    @Select("select * from `group` where id=#{id}")
    Group getGroupById(@Param("id")int id);

    @Delete("delete from `group` where id=#{id}")
    Integer delGroup(@Param("id")int id);

    @Select("select count(1) from `group` where `name`=#{name}")
    Integer checkGroupIsExist(@Param("name")String name);

    Integer addGroup(Group group);

}
