package com.product.qq.dao;

import com.product.qq.dto.Message;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface IMessageDao {
    @Select("select * from message where send_to=#{id}  and type=1 and status=0 order by created_time asc")            //1:私聊，2：群聊
    List<Message> getGenPriMsg(@Param("id") Integer id);      //普通消息

    List<Message> getGenGroMsg(@Param("gids")List<Integer> gid);

    @Select("select * from message where ( send_to=#{id} and type in (3,4,5,6,10,54,55,56) ) or ( user_id=#{id} and type in (7,8,9) ) and status=0")
    List<Message> getContMsg(Integer id);       //控制消息

    @Select("select * from message where ((send_to =#{id} and user_id=#{from}) or (send_to =#{from} and user_id=#{id}) )and type=1 Order by created_time ASC Limit #{index},#{num}")
    List<Message> getPriHistMsg(@Param("id") int id,@Param("from") int from,@Param("index") int index,@Param("num")int num);           //历史消息

    @Select("select * from message where send_to =#{from} and type=2  Order by created_time ASC Limit #{index},#{num}")
    List<Message> getGroHistMsg(@Param("from") Integer from,@Param("index") Integer index,@Param("num")Integer num);

    Integer addMessage( Message message);

    @Select("select * from message where id=#{id}")
    Message getMessageById(@Param("id") Integer id);

    @Delete("delete from message where id=#{id}")
    Integer delMessage(@Param("id") Integer id);

    @Select("select id from message where user_id=#{user_id} and send_to=#{send_to} and type=#{type}")
    List<Integer> checkMsgIsExist(@Param("user_id")int user_id,@Param("send_to")int send_to,@Param("type")int type);

    @Update("update message  set status=1 where send_to=#{send_to} and type=#{type} and user_id=#{user_id} ")
    Integer updateMsgStatus(@Param("user_id")int user_id,@Param("send_to")int send_to,@Param("type")int type);

    @Update("update message set pos=pos+1 where id=#{id}")
    Integer incrementMsgPos(@Param("id")int id);

    @Update("update message set neg=neg+1 where id=#{id}")
    Integer incrementMsgNeg(@Param("id")int id);
}
