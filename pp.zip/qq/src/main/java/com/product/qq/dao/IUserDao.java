package com.product.qq.dao;

import com.product.qq.dto.User;
import org.apache.ibatis.annotations.MapKey;

import java.util.List;
import java.util.Map;

public interface IUserDao {
    @MapKey("id")
    Map<Integer, User> getAllUser();
    List<Integer> getFriends(Integer id);
    List<Integer> getGroups(Integer id);
    User getUserById(Integer id);
    List<User> getUserByName(String name);
    User getUserByAcctPwd(String account,String passwd);
    Integer addUser(User user);
    Integer modifyUser(User user);
}
